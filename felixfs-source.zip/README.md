# FelixFS source

This package contains the native implementation behind the FelixQR demo.
It includes the Rust geometry/volume core, CLI, platform adapters, Android
application source, protocol specification, tests, and the exact goat image
set used by the public demonstration. The web builder source is browsable in
the [FelixQR site repository](https://github.com/FelixAGI/felixagi.github.io).

Start with [BUILD.md](BUILD.md), then [FELIXFS-SPEC.md](FELIXFS-SPEC.md).

The source package excludes compiled binaries, local paths and logs, signing
keys, and visitor files. The bundled `vendor/` crates are Microsoft's
`windows-sys` and `windows-link`, with their original licenses included.

FelixFS is licensed under MIT; see [LICENSE](LICENSE).
