use crate::{
    error::{FelixError, Result},
    lattice::{Coordinate, Lattice},
};

pub const OPCODE_COUNT: usize = 28;

#[derive(Clone, Debug)]
pub enum Instruction {
    Const {
        value: u64,
    },
    Coord {
        axis: usize,
    },
    LevelCoord {
        level: usize,
        axis: usize,
    },
    Channel,
    DimensionCount,
    LevelCount,
    Add {
        a: usize,
        b: usize,
    },
    Sub {
        a: usize,
        b: usize,
    },
    Mul {
        a: usize,
        b: usize,
    },
    Div {
        a: usize,
        b: usize,
    },
    Mod {
        a: usize,
        b: usize,
    },
    Xor {
        a: usize,
        b: usize,
    },
    And {
        a: usize,
        b: usize,
    },
    Or {
        a: usize,
        b: usize,
    },
    Not {
        a: usize,
    },
    ShiftLeft {
        a: usize,
        b: usize,
    },
    ShiftRight {
        a: usize,
        b: usize,
    },
    RotateLeft {
        a: usize,
        b: usize,
    },
    RotateRight {
        a: usize,
        b: usize,
    },
    Min {
        a: usize,
        b: usize,
    },
    Max {
        a: usize,
        b: usize,
    },
    Equal {
        a: usize,
        b: usize,
    },
    Less {
        a: usize,
        b: usize,
    },
    Greater {
        a: usize,
        b: usize,
    },
    Select {
        condition: usize,
        yes: usize,
        no: usize,
    },
    ByteSwap {
        a: usize,
    },
    PopCount {
        a: usize,
    },
    Mix64 {
        a: usize,
    },
}

#[derive(Clone, Debug)]
pub struct Program {
    pub instructions: Vec<Instruction>,
    pub outputs: Vec<usize>,
}

impl Instruction {
    fn references(&self) -> Vec<usize> {
        use Instruction::*;
        match *self {
            Add { a, b }
            | Sub { a, b }
            | Mul { a, b }
            | Div { a, b }
            | Mod { a, b }
            | Xor { a, b }
            | And { a, b }
            | Or { a, b }
            | ShiftLeft { a, b }
            | ShiftRight { a, b }
            | RotateLeft { a, b }
            | RotateRight { a, b }
            | Min { a, b }
            | Max { a, b }
            | Equal { a, b }
            | Less { a, b }
            | Greater { a, b } => vec![a, b],
            Not { a } | ByteSwap { a } | PopCount { a } | Mix64 { a } => vec![a],
            Select { condition, yes, no } => vec![condition, yes, no],
            _ => Vec::new(),
        }
    }
}

impl Program {
    pub fn validate(&self, lattice: &Lattice) -> Result<()> {
        if self.instructions.is_empty() || self.outputs.is_empty() {
            return Err(FelixError::Invalid(
                "VM program and outputs must not be empty".into(),
            ));
        }
        for (index, instruction) in self.instructions.iter().enumerate() {
            for reference in instruction.references() {
                if reference >= index {
                    return Err(FelixError::Invalid(format!(
                        "instruction {index} has forward reference {reference}"
                    )));
                }
            }
            match instruction {
                Instruction::Coord { axis } if *axis >= lattice.dimensions() => {
                    return Err(FelixError::Invalid(format!(
                        "coordinate axis {axis} does not exist"
                    )));
                }
                Instruction::LevelCoord { level, axis }
                    if *level >= lattice.levels.len()
                        || *axis >= lattice.levels[*level].axes.len() =>
                {
                    return Err(FelixError::Invalid(format!(
                        "recursive coordinate {level}:{axis} does not exist"
                    )));
                }
                _ => {}
            }
        }
        for &output in &self.outputs {
            if output >= self.instructions.len() {
                return Err(FelixError::Invalid(format!(
                    "output {output} does not exist"
                )));
            }
        }
        if self.outputs.len() != 1 && self.outputs.len() != lattice.channels as usize {
            return Err(FelixError::Invalid(
                "VM must have one shared output or exactly one output per channel".into(),
            ));
        }
        Ok(())
    }

    pub fn evaluate(&self, lattice: &Lattice, coordinate: &Coordinate) -> Result<u8> {
        lattice.coordinate_to_address(coordinate)?;
        let flat: Vec<u32> = lattice.flatten(coordinate).collect();
        let mut values: Vec<u64> = Vec::with_capacity(self.instructions.len());
        for instruction in &self.instructions {
            use Instruction::*;
            let read = |index: usize| values[index];
            let value = match *instruction {
                Const { value } => value,
                Coord { axis } => flat[axis] as u64,
                LevelCoord { level, axis } => coordinate.levels[level][axis] as u64,
                Channel => coordinate.channel as u64,
                DimensionCount => lattice.dimensions() as u64,
                LevelCount => lattice.levels.len() as u64,
                Add { a, b } => read(a).wrapping_add(read(b)),
                Sub { a, b } => read(a).wrapping_sub(read(b)),
                Mul { a, b } => read(a).wrapping_mul(read(b)),
                Div { a, b } => {
                    if read(b) == 0 {
                        0
                    } else {
                        read(a) / read(b)
                    }
                }
                Mod { a, b } => {
                    if read(b) == 0 {
                        0
                    } else {
                        read(a) % read(b)
                    }
                }
                Xor { a, b } => read(a) ^ read(b),
                And { a, b } => read(a) & read(b),
                Or { a, b } => read(a) | read(b),
                Not { a } => !read(a),
                ShiftLeft { a, b } => read(a).wrapping_shl((read(b) & 63) as u32),
                ShiftRight { a, b } => read(a).wrapping_shr((read(b) & 63) as u32),
                RotateLeft { a, b } => read(a).rotate_left((read(b) & 63) as u32),
                RotateRight { a, b } => read(a).rotate_right((read(b) & 63) as u32),
                Min { a, b } => read(a).min(read(b)),
                Max { a, b } => read(a).max(read(b)),
                Equal { a, b } => u64::from(read(a) == read(b)),
                Less { a, b } => u64::from(read(a) < read(b)),
                Greater { a, b } => u64::from(read(a) > read(b)),
                Select { condition, yes, no } => {
                    if read(condition) != 0 {
                        read(yes)
                    } else {
                        read(no)
                    }
                }
                ByteSwap { a } => read(a).swap_bytes(),
                PopCount { a } => read(a).count_ones() as u64,
                Mix64 { a } => mix64(read(a)),
            };
            values.push(value);
        }
        let output = if self.outputs.len() == 1 {
            self.outputs[0]
        } else {
            self.outputs[coordinate.channel as usize]
        };
        Ok((values[output] & 255) as u8)
    }
}

pub fn mix64(mut value: u64) -> u64 {
    value ^= value >> 30;
    value = value.wrapping_mul(0xbf58_476d_1ce4_e5b9);
    value ^= value >> 27;
    value = value.wrapping_mul(0x94d0_49bb_1331_11eb);
    value ^ (value >> 31)
}
