use std::{ffi::c_char, ptr, slice, str};

use crate::phi::BranchKind;
use crate::{FelixVolume, bignat::BigNat};

pub struct FelixHandle(FelixVolume);

unsafe fn input<'a>(pointer: *const u8, length: usize) -> Option<&'a [u8]> {
    if pointer.is_null() {
        None
    } else {
        Some(unsafe { slice::from_raw_parts(pointer, length) })
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn felix_open(payload: *const u8, length: usize) -> *mut FelixHandle {
    let Some(bytes) = (unsafe { input(payload, length) }) else {
        return ptr::null_mut();
    };
    let Ok(text) = str::from_utf8(bytes) else {
        return ptr::null_mut();
    };
    match FelixVolume::decode(text) {
        Ok(volume) => Box::into_raw(Box::new(FelixHandle(volume))),
        Err(_) => ptr::null_mut(),
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn felix_close(handle: *mut FelixHandle) {
    if !handle.is_null() {
        drop(unsafe { Box::from_raw(handle) });
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn felix_read(
    handle: *const FelixHandle,
    path: *const c_char,
    path_length: usize,
    offset: u64,
    output: *mut u8,
    output_length: usize,
) -> isize {
    if handle.is_null() || output.is_null() {
        return -1;
    }
    let Some(path_bytes) = (unsafe { input(path.cast(), path_length) }) else {
        return -1;
    };
    let Ok(path) = str::from_utf8(path_bytes) else {
        return -1;
    };
    let volume = unsafe { &(*handle).0 };
    match volume.read(path, &BigNat::from(offset), output_length) {
        Ok(bytes) => {
            unsafe {
                ptr::copy_nonoverlapping(bytes.as_ptr(), output, bytes.len());
            }
            bytes.len() as isize
        }
        Err(_) => -1,
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn felix_size(
    handle: *const FelixHandle,
    path: *const c_char,
    path_length: usize,
) -> u64 {
    if handle.is_null() {
        return u64::MAX;
    }
    let Some(path_bytes) = (unsafe { input(path.cast(), path_length) }) else {
        return u64::MAX;
    };
    let Ok(path) = str::from_utf8(path_bytes) else {
        return u64::MAX;
    };
    unsafe { &(*handle).0 }
        .phi
        .metadata(path)
        .ok()
        .and_then(|metadata| metadata.length.to_usize())
        .and_then(|length| length.try_into().ok())
        .unwrap_or(u64::MAX)
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn felix_kind(
    handle: *const FelixHandle,
    path: *const c_char,
    path_length: usize,
) -> i32 {
    let Some((volume, path)) = (unsafe { volume_path(handle, path, path_length) }) else {
        return 0;
    };
    match volume.phi.metadata(path).map(|metadata| metadata.kind) {
        Ok(BranchKind::File) => 1,
        Ok(BranchKind::Directory) => 2,
        Err(_) => 0,
    }
}

#[unsafe(no_mangle)]
pub unsafe extern "C" fn felix_list(
    handle: *const FelixHandle,
    path: *const c_char,
    path_length: usize,
    output: *mut u8,
    output_capacity: usize,
) -> isize {
    let Some((volume, path)) = (unsafe { volume_path(handle, path, path_length) }) else {
        return -1;
    };
    let Ok(items) = volume.phi.list(path) else {
        return -1;
    };
    let mut text = String::new();
    for item in items {
        let kind = if item.kind == BranchKind::Directory {
            'D'
        } else {
            'F'
        };
        text.push_str(&format!(
            "{kind}|{}|{}|{}|{}\n",
            item.rotation_state, item.rotation_radix, item.length, item.name
        ));
    }
    if output.is_null() || output_capacity < text.len() {
        return text.len() as isize;
    }
    unsafe {
        ptr::copy_nonoverlapping(text.as_ptr(), output, text.len());
    }
    text.len() as isize
}

unsafe fn volume_path<'a>(
    handle: *const FelixHandle,
    path: *const c_char,
    path_length: usize,
) -> Option<(&'a FelixVolume, &'a str)> {
    if handle.is_null() {
        return None;
    }
    let bytes = unsafe { input(path.cast(), path_length) }?;
    let path = str::from_utf8(bytes).ok()?;
    Some((unsafe { &(*handle).0 }, path))
}
