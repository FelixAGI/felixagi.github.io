use std::fmt::{Display, Formatter};

#[derive(Debug)]
pub enum FelixError {
    Invalid(String),
    NotFound(String),
    NotDirectory(String),
    IsDirectory(String),
    OutOfRange(String),
    Io(std::io::Error),
}

impl Display for FelixError {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Invalid(s) => write!(f, "invalid Felix object: {s}"),
            Self::NotFound(s) => write!(f, "not found: {s}"),
            Self::NotDirectory(s) => write!(f, "not a directory: {s}"),
            Self::IsDirectory(s) => write!(f, "is a directory: {s}"),
            Self::OutOfRange(s) => write!(f, "out of range: {s}"),
            Self::Io(e) => Display::fmt(e, f),
        }
    }
}

impl std::error::Error for FelixError {}

impl From<std::io::Error> for FelixError {
    fn from(value: std::io::Error) -> Self {
        Self::Io(value)
    }
}

pub type Result<T> = std::result::Result<T, FelixError>;
