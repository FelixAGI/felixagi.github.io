use std::{
    ffi::c_void,
    mem::{offset_of, size_of},
    path::Path,
    process::Command,
    ptr, slice,
};

use windows_sys::Win32::{
    Foundation::{STATUS_CLOUD_FILE_INVALID_REQUEST, STATUS_SUCCESS},
    Storage::{
        CloudFilters::*,
        FileSystem::{FILE_ATTRIBUTE_DIRECTORY, FILE_ATTRIBUTE_READONLY},
    },
};

use crate::{
    FelixError, FelixVolume, Result,
    bignat::BigNat,
    phi::{BranchKind, Metadata},
};

struct MountContext {
    volume: FelixVolume,
}

pub struct WindowsMount {
    connection: CF_CONNECTION_KEY,
    root: Vec<u16>,
    drive: String,
    _context: Box<MountContext>,
}

pub fn mount(volume: FelixVolume, root: &Path, drive: &str) -> Result<WindowsMount> {
    validate_drive(drive)?;
    std::fs::create_dir_all(root)?;
    if std::fs::read_dir(root)?.next().is_some() {
        return Err(FelixError::Invalid(format!(
            "Windows mount root is not empty: {}",
            root.display()
        )));
    }
    let root = root.canonicalize()?;
    let root_wide = wide(&root);
    register(&root_wide)?;
    if let Err(error) = populate(&volume, &root) {
        unsafe { CfUnregisterSyncRoot(root_wide.as_ptr()) };
        return Err(error);
    }

    let context = Box::new(MountContext { volume });
    let callbacks = [
        CF_CALLBACK_REGISTRATION {
            Type: CF_CALLBACK_TYPE_FETCH_DATA,
            Callback: Some(fetch_data),
        },
        CF_CALLBACK_REGISTRATION {
            Type: CF_CALLBACK_TYPE_NONE,
            Callback: None,
        },
    ];
    let mut connection = 0;
    check(
        unsafe {
            CfConnectSyncRoot(
                root_wide.as_ptr(),
                callbacks.as_ptr(),
                (&*context as *const MountContext).cast(),
                CF_CONNECT_FLAG_NONE,
                &mut connection,
            )
        },
        "CfConnectSyncRoot",
    )?;

    let status = Command::new("subst.exe").arg(drive).arg(&root).status()?;
    if !status.success() {
        unsafe { CfDisconnectSyncRoot(connection) };
        unsafe { CfUnregisterSyncRoot(root_wide.as_ptr()) };
        return Err(FelixError::Invalid(format!(
            "subst could not map {drive} to {}",
            root.display()
        )));
    }
    Ok(WindowsMount {
        connection,
        root: root_wide,
        drive: drive.to_string(),
        _context: context,
    })
}

pub fn unmount(root: &Path, drive: &str) -> Result<()> {
    validate_drive(drive)?;
    let _ = Command::new("subst.exe").arg(drive).arg("/D").status();
    let root = root.canonicalize().unwrap_or_else(|_| root.to_path_buf());
    let root = wide(&root);
    let result = unsafe { CfUnregisterSyncRoot(root.as_ptr()) };
    if result < 0 {
        return Err(FelixError::Invalid(format!(
            "CfUnregisterSyncRoot failed with HRESULT 0x{:08x}",
            result as u32
        )));
    }
    Ok(())
}

impl WindowsMount {
    pub fn wait(self) -> ! {
        println!("FelixFS mounted read-only at {}", self.drive);
        loop {
            std::thread::park();
        }
    }
}

impl Drop for WindowsMount {
    fn drop(&mut self) {
        let _ = Command::new("subst.exe")
            .arg(&self.drive)
            .arg("/D")
            .status();
        unsafe { CfDisconnectSyncRoot(self.connection) };
        unsafe { CfUnregisterSyncRoot(self.root.as_ptr()) };
    }
}

fn register(root: &[u16]) -> Result<()> {
    let provider = wide_str("FelixFS");
    let version = wide_str(env!("CARGO_PKG_VERSION"));
    let registration = CF_SYNC_REGISTRATION {
        StructSize: size_of::<CF_SYNC_REGISTRATION>() as u32,
        ProviderName: provider.as_ptr(),
        ProviderVersion: version.as_ptr(),
        ..Default::default()
    };
    let policies = CF_SYNC_POLICIES {
        StructSize: size_of::<CF_SYNC_POLICIES>() as u32,
        Hydration: CF_HYDRATION_POLICY {
            Primary: CF_HYDRATION_POLICY_PARTIAL,
            Modifier: CF_HYDRATION_POLICY_MODIFIER_STREAMING_ALLOWED,
        },
        Population: CF_POPULATION_POLICY {
            Primary: CF_POPULATION_POLICY_FULL,
            Modifier: CF_POPULATION_POLICY_MODIFIER_NONE,
        },
        InSync: CF_INSYNC_POLICY_NONE,
        HardLink: CF_HARDLINK_POLICY_NONE,
        PlaceholderManagement: CF_PLACEHOLDER_MANAGEMENT_POLICY_DEFAULT,
    };
    check(
        unsafe {
            CfRegisterSyncRoot(
                root.as_ptr(),
                &registration,
                &policies,
                CF_REGISTER_FLAG_MARK_IN_SYNC_ON_ROOT,
            )
        },
        "CfRegisterSyncRoot",
    )
}

fn populate(volume: &FelixVolume, root: &Path) -> Result<()> {
    populate_directory(volume, root, "/")
}

fn populate_directory(volume: &FelixVolume, local: &Path, virtual_path: &str) -> Result<()> {
    for entry in volume.phi.list(virtual_path)? {
        create_placeholder(local, &entry)?;
        if entry.kind == BranchKind::Directory {
            populate_directory(volume, &local.join(&entry.name), &entry.path)?;
        }
    }
    Ok(())
}

fn create_placeholder(base: &Path, entry: &Metadata) -> Result<()> {
    let name = wide_str(&entry.name);
    let identity = entry.path.as_bytes();
    let attributes = if entry.kind == BranchKind::Directory {
        FILE_ATTRIBUTE_DIRECTORY
    } else {
        FILE_ATTRIBUTE_READONLY
    };
    let size = entry
        .length
        .to_u64()
        .and_then(|value| i64::try_from(value).ok())
        .ok_or_else(|| {
            FelixError::OutOfRange(format!("{} exceeds Windows file size", entry.path))
        })?;
    let mut info = CF_PLACEHOLDER_CREATE_INFO {
        RelativeFileName: name.as_ptr(),
        FsMetadata: CF_FS_METADATA {
            BasicInfo: windows_sys::Win32::Storage::FileSystem::FILE_BASIC_INFO {
                FileAttributes: attributes,
                ..Default::default()
            },
            FileSize: size,
        },
        FileIdentity: identity.as_ptr().cast(),
        FileIdentityLength: identity.len() as u32,
        Flags: CF_PLACEHOLDER_CREATE_FLAG_MARK_IN_SYNC,
        ..Default::default()
    };
    let mut processed = 0;
    let base = wide(base);
    check(
        unsafe {
            CfCreatePlaceholders(
                base.as_ptr(),
                &mut info,
                1,
                CF_CREATE_FLAG_STOP_ON_ERROR,
                &mut processed,
            )
        },
        "CfCreatePlaceholders",
    )?;
    check(info.Result, "placeholder result")
}

unsafe extern "system" fn fetch_data(
    info: *const CF_CALLBACK_INFO,
    parameters: *const CF_CALLBACK_PARAMETERS,
) {
    let result = unsafe { transfer_requested_data(&*info, &*parameters) };
    if let Err(error) = result {
        eprintln!("FelixFS hydration failed: {error}");
        unsafe { transfer_failure(&*info, &*parameters) };
    }
}

unsafe fn transfer_requested_data(
    info: &CF_CALLBACK_INFO,
    parameters: &CF_CALLBACK_PARAMETERS,
) -> Result<()> {
    let context = unsafe { &*(info.CallbackContext as *const MountContext) };
    let identity = unsafe {
        slice::from_raw_parts(
            info.FileIdentity.cast::<u8>(),
            info.FileIdentityLength as usize,
        )
    };
    let path = std::str::from_utf8(identity)
        .map_err(|_| FelixError::Invalid("Windows placeholder identity is not UTF-8".into()))?;
    let fetch = unsafe { parameters.Anonymous.FetchData };
    let mut offset = fetch.RequiredFileOffset;
    let mut remaining = fetch.RequiredLength;
    while remaining > 0 {
        let length = remaining.min(1024 * 1024) as usize;
        let bytes = context
            .volume
            .read(path, &BigNat::from(offset as u64), length)?;
        if bytes.is_empty() {
            break;
        }
        transfer(info, offset, &bytes, STATUS_SUCCESS)?;
        offset += bytes.len() as i64;
        remaining -= bytes.len() as i64;
    }
    Ok(())
}

fn transfer(info: &CF_CALLBACK_INFO, offset: i64, bytes: &[u8], status: i32) -> Result<()> {
    let operation = CF_OPERATION_INFO {
        StructSize: size_of::<CF_OPERATION_INFO>() as u32,
        Type: CF_OPERATION_TYPE_TRANSFER_DATA,
        ConnectionKey: info.ConnectionKey,
        TransferKey: info.TransferKey,
        CorrelationVector: info.CorrelationVector,
        SyncStatus: ptr::null(),
        RequestKey: info.RequestKey,
    };
    let mut parameters = CF_OPERATION_PARAMETERS {
        ParamSize: (offset_of!(CF_OPERATION_PARAMETERS, Anonymous)
            + size_of::<CF_OPERATION_PARAMETERS_0_0>()) as u32,
        Anonymous: CF_OPERATION_PARAMETERS_0 {
            TransferData: CF_OPERATION_PARAMETERS_0_0 {
                Flags: CF_OPERATION_TRANSFER_DATA_FLAG_NONE,
                CompletionStatus: status,
                Buffer: if bytes.is_empty() {
                    ptr::null()
                } else {
                    bytes.as_ptr().cast::<c_void>()
                },
                Offset: offset,
                Length: bytes.len() as i64,
            },
        },
    };
    check(
        unsafe { CfExecute(&operation, &mut parameters) },
        "CfExecute(TRANSFER_DATA)",
    )
}

unsafe fn transfer_failure(info: &CF_CALLBACK_INFO, parameters: &CF_CALLBACK_PARAMETERS) {
    let fetch = unsafe { parameters.Anonymous.FetchData };
    let bytes = vec![0; fetch.RequiredLength.max(0).min(4096) as usize];
    let _ = transfer(
        info,
        fetch.RequiredFileOffset,
        &bytes,
        STATUS_CLOUD_FILE_INVALID_REQUEST,
    );
}

fn check(result: i32, operation: &str) -> Result<()> {
    if result >= 0 {
        Ok(())
    } else {
        Err(FelixError::Invalid(format!(
            "{operation} failed with HRESULT 0x{:08x}",
            result as u32
        )))
    }
}

fn validate_drive(drive: &str) -> Result<()> {
    let bytes = drive.as_bytes();
    if bytes.len() == 2 && bytes[0].is_ascii_alphabetic() && bytes[1] == b':' {
        Ok(())
    } else {
        Err(FelixError::Invalid(format!(
            "Windows drive must look like X:, got {drive}"
        )))
    }
}

fn wide(path: &Path) -> Vec<u16> {
    wide_str(&path.to_string_lossy())
}

fn wide_str(value: &str) -> Vec<u16> {
    value.encode_utf16().chain(std::iter::once(0)).collect()
}
