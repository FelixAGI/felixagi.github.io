use std::{
    io::{Read, Write},
    net::{TcpListener, TcpStream},
    sync::Arc,
    thread,
};

use crate::{
    FelixVolume,
    bignat::BigNat,
    error::{FelixError, Result},
    phi::{BranchKind, Metadata},
};

pub fn serve(volume: FelixVolume, address: &str) -> Result<()> {
    let listener = TcpListener::bind(address)?;
    let volume = Arc::new(volume);
    for stream in listener.incoming() {
        let stream = stream?;
        let volume = Arc::clone(&volume);
        thread::spawn(move || {
            let _ = handle(stream, &volume);
        });
    }
    Ok(())
}

pub fn serve_one(listener: TcpListener, volume: Arc<FelixVolume>) -> Result<()> {
    let (stream, _) = listener.accept()?;
    handle(stream, &volume)
}

fn handle(mut stream: TcpStream, volume: &FelixVolume) -> Result<()> {
    let request = read_request(&mut stream)?;
    let mut first = request.lines().next().unwrap_or("").split_whitespace();
    let method = first.next().unwrap_or("");
    let target = first.next().unwrap_or("");
    let path = url_decode(target.split('?').next().unwrap_or("/"))?;
    match method {
        "OPTIONS" => write_response(
            &mut stream,
            "200 OK",
            &[
                ("Allow", "OPTIONS, PROPFIND, HEAD, GET"),
                ("DAV", "1"),
                ("MS-Author-Via", "DAV"),
            ],
            &[],
        ),
        "PROPFIND" => propfind(
            &mut stream,
            volume,
            &path,
            header(&request, "Depth").unwrap_or("0") == "1",
        ),
        "HEAD" => file_response(&mut stream, volume, &path, None, false),
        "GET" => file_response(&mut stream, volume, &path, header(&request, "Range"), true),
        _ => write_response(
            &mut stream,
            "405 Method Not Allowed",
            &[("Allow", "OPTIONS, PROPFIND, HEAD, GET")],
            &[],
        ),
    }
}

fn read_request(stream: &mut TcpStream) -> Result<String> {
    let mut bytes = Vec::new();
    let mut buffer = [0u8; 2048];
    while bytes.len() < 65_536 {
        let count = stream.read(&mut buffer)?;
        if count == 0 {
            break;
        }
        bytes.extend_from_slice(&buffer[..count]);
        if bytes.windows(4).any(|window| window == b"\r\n\r\n") {
            break;
        }
    }
    String::from_utf8(bytes).map_err(|_| FelixError::Invalid("non-UTF-8 WebDAV request".into()))
}

fn header<'a>(request: &'a str, name: &str) -> Option<&'a str> {
    request.lines().skip(1).find_map(|line| {
        let (key, value) = line.split_once(':')?;
        key.eq_ignore_ascii_case(name).then(|| value.trim())
    })
}

fn propfind(
    stream: &mut TcpStream,
    volume: &FelixVolume,
    path: &str,
    children: bool,
) -> Result<()> {
    let metadata = match volume.phi.metadata(path) {
        Ok(metadata) => metadata,
        Err(_) => return write_response(stream, "404 Not Found", &[], &[]),
    };
    let mut entries = vec![metadata];
    if children && entries[0].kind == BranchKind::Directory {
        entries.extend(volume.phi.list(path)?);
    }
    let mut body =
        String::from("<?xml version=\"1.0\" encoding=\"utf-8\"?><D:multistatus xmlns:D=\"DAV:\">");
    for entry in entries {
        body.push_str(&dav_entry(&entry));
    }
    body.push_str("</D:multistatus>");
    write_response(
        stream,
        "207 Multi-Status",
        &[("Content-Type", "application/xml; charset=utf-8")],
        body.as_bytes(),
    )
}

fn dav_entry(entry: &Metadata) -> String {
    let collection = if entry.kind == BranchKind::Directory {
        "<D:collection/>"
    } else {
        ""
    };
    format!(
        "<D:response><D:href>{}</D:href><D:propstat><D:prop><D:displayname>{}</D:displayname><D:resourcetype>{}</D:resourcetype><D:getcontentlength>{}</D:getcontentlength><D:getetag>\"{}-{}\"</D:getetag></D:prop><D:status>HTTP/1.1 200 OK</D:status></D:propstat></D:response>",
        xml(&url_encode_path(&entry.path)),
        xml(&entry.name),
        collection,
        entry.length,
        entry.rotation_state,
        entry.rotation_radix,
    )
}

fn file_response(
    stream: &mut TcpStream,
    volume: &FelixVolume,
    path: &str,
    range: Option<&str>,
    body: bool,
) -> Result<()> {
    let metadata = match volume.phi.metadata(path) {
        Ok(metadata) => metadata,
        Err(_) => return write_response(stream, "404 Not Found", &[], &[]),
    };
    if metadata.kind == BranchKind::Directory {
        return write_response(stream, "405 Method Not Allowed", &[], &[]);
    }
    let (start, count, status, content_range) = if let Some(range) = range {
        let range = range
            .strip_prefix("bytes=")
            .ok_or_else(|| FelixError::Invalid("unsupported Range header".into()))?;
        let (start, end) = range
            .split_once('-')
            .ok_or_else(|| FelixError::Invalid("invalid Range header".into()))?;
        let start = BigNat::from_decimal(start)?;
        let end = if end.is_empty() {
            metadata.length.sub(&BigNat::one())?
        } else {
            BigNat::from_decimal(end)?
        };
        if end < start || end >= metadata.length {
            return write_response(stream, "416 Range Not Satisfiable", &[], &[]);
        }
        let count = end.sub(&start)?.add_u64(1);
        let content_range = format!("bytes {start}-{end}/{}", metadata.length);
        (start, count, "206 Partial Content", Some(content_range))
    } else {
        (BigNat::zero(), metadata.length.clone(), "200 OK", None)
    };
    let mut headers = vec![
        (
            "Content-Type".to_string(),
            "application/octet-stream".to_string(),
        ),
        ("Accept-Ranges".to_string(), "bytes".to_string()),
        ("Content-Length".to_string(), count.to_string()),
    ];
    if let Some(value) = content_range {
        headers.push(("Content-Range".into(), value));
    }
    write_headers(stream, status, &headers)?;
    if body {
        let mut offset = start;
        let mut remaining = count;
        while !remaining.is_zero() {
            let chunk = remaining
                .to_usize()
                .map_or(65_536, |value| value.min(65_536));
            let bytes = volume.read(path, &offset, chunk)?;
            if bytes.is_empty() {
                break;
            }
            stream.write_all(&bytes)?;
            offset = offset.add_u64(bytes.len() as u64);
            remaining = remaining.sub(&BigNat::from(bytes.len()))?;
        }
    }
    Ok(())
}

fn write_response(
    stream: &mut TcpStream,
    status: &str,
    headers: &[(&str, &str)],
    body: &[u8],
) -> Result<()> {
    let mut owned: Vec<(String, String)> = headers
        .iter()
        .map(|(a, b)| ((*a).into(), (*b).into()))
        .collect();
    owned.push(("Content-Length".into(), body.len().to_string()));
    write_headers(stream, status, &owned)?;
    stream.write_all(body)?;
    Ok(())
}

fn write_headers(stream: &mut TcpStream, status: &str, headers: &[(String, String)]) -> Result<()> {
    write!(stream, "HTTP/1.1 {status}\r\nConnection: close\r\n")?;
    for (name, value) in headers {
        write!(stream, "{name}: {value}\r\n")?;
    }
    write!(stream, "\r\n")?;
    Ok(())
}

fn url_decode(value: &str) -> Result<String> {
    let mut bytes = Vec::new();
    let mut input = value.as_bytes().iter().copied();
    while let Some(byte) = input.next() {
        if byte == b'%' {
            let high = hex(input
                .next()
                .ok_or_else(|| FelixError::Invalid("bad URL escape".into()))?)?;
            let low = hex(input
                .next()
                .ok_or_else(|| FelixError::Invalid("bad URL escape".into()))?)?;
            bytes.push(high << 4 | low);
        } else {
            bytes.push(byte);
        }
    }
    String::from_utf8(bytes).map_err(|_| FelixError::Invalid("URL path is not UTF-8".into()))
}

fn hex(byte: u8) -> Result<u8> {
    match byte {
        b'0'..=b'9' => Ok(byte - b'0'),
        b'a'..=b'f' => Ok(byte - b'a' + 10),
        b'A'..=b'F' => Ok(byte - b'A' + 10),
        _ => Err(FelixError::Invalid("bad URL escape".into())),
    }
}

fn url_encode_path(value: &str) -> String {
    value
        .bytes()
        .map(|byte| match byte {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'/' | b'-' | b'_' | b'.' => {
                (byte as char).to_string()
            }
            _ => format!("%{byte:02X}"),
        })
        .collect()
}

fn xml(value: &str) -> String {
    value
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
}
