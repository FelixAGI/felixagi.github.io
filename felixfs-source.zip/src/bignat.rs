use std::{
    cmp::Ordering,
    fmt::{Display, Formatter},
};

use crate::error::{FelixError, Result};

#[derive(Clone, Debug, Default, Eq)]
pub struct BigNat(pub(crate) Vec<u32>);

impl PartialEq for BigNat {
    fn eq(&self, other: &Self) -> bool {
        self.words() == other.words()
    }
}

impl Ord for BigNat {
    fn cmp(&self, other: &Self) -> Ordering {
        let a = self.words();
        let b = other.words();
        a.len()
            .cmp(&b.len())
            .then_with(|| a.iter().rev().cmp(b.iter().rev()))
    }
}

impl PartialOrd for BigNat {
    fn partial_cmp(&self, other: &Self) -> Option<Ordering> {
        Some(self.cmp(other))
    }
}

impl From<u8> for BigNat {
    fn from(v: u8) -> Self {
        Self::from(v as u64)
    }
}
impl From<u32> for BigNat {
    fn from(v: u32) -> Self {
        Self::from(v as u64)
    }
}
impl From<usize> for BigNat {
    fn from(v: usize) -> Self {
        Self::from(v as u64)
    }
}

impl From<u64> for BigNat {
    fn from(value: u64) -> Self {
        if value == 0 {
            Self(vec![])
        } else if value <= u32::MAX as u64 {
            Self(vec![value as u32])
        } else {
            Self(vec![value as u32, (value >> 32) as u32])
        }
    }
}

impl BigNat {
    pub fn zero() -> Self {
        Self(vec![])
    }
    pub fn one() -> Self {
        Self(vec![1])
    }
    pub fn is_zero(&self) -> bool {
        self.words().is_empty()
    }
    pub fn words(&self) -> &[u32] {
        let end = self
            .0
            .iter()
            .rposition(|&word| word != 0)
            .map_or(0, |i| i + 1);
        &self.0[..end]
    }
    pub fn to_u64(&self) -> Option<u64> {
        match self.words() {
            [] => Some(0),
            [low] => Some(*low as u64),
            [low, high] => Some(*low as u64 | (*high as u64) << 32),
            _ => None,
        }
    }
    fn normalize(&mut self) {
        while self.0.last() == Some(&0) {
            self.0.pop();
        }
    }

    pub fn add(&self, other: &Self) -> Self {
        let size = self.words().len().max(other.words().len());
        let mut out = Vec::with_capacity(size + 1);
        let mut carry = 0u64;
        for i in 0..size {
            let sum = self.0.get(i).copied().unwrap_or(0) as u64
                + other.0.get(i).copied().unwrap_or(0) as u64
                + carry;
            out.push(sum as u32);
            carry = sum >> 32;
        }
        if carry != 0 {
            out.push(carry as u32);
        }
        Self(out)
    }

    pub fn add_u64(&self, value: u64) -> Self {
        self.add(&Self::from(value))
    }

    pub fn sub(&self, other: &Self) -> Result<Self> {
        if self < other {
            return Err(FelixError::OutOfRange("negative BigNat result".into()));
        }
        let mut out = Vec::with_capacity(self.words().len());
        let mut borrow = 0i64;
        for i in 0..self.words().len() {
            let value = self.0[i] as i64 - other.0.get(i).copied().unwrap_or(0) as i64 - borrow;
            if value < 0 {
                out.push((value + (1i64 << 32)) as u32);
                borrow = 1;
            } else {
                out.push(value as u32);
                borrow = 0;
            }
        }
        let mut result = Self(out);
        result.normalize();
        Ok(result)
    }

    pub fn mul_u32(&self, factor: u32) -> Self {
        if factor == 0 || self.is_zero() {
            return Self::zero();
        }
        let mut out = Vec::with_capacity(self.words().len() + 1);
        let mut carry = 0u64;
        for &word in self.words() {
            let product = word as u64 * factor as u64 + carry;
            out.push(product as u32);
            carry = product >> 32;
        }
        if carry != 0 {
            out.push(carry as u32);
        }
        Self(out)
    }

    pub fn mul(&self, other: &Self) -> Self {
        if self.is_zero() || other.is_zero() {
            return Self::zero();
        }
        let mut out = vec![0u32; self.words().len() + other.words().len()];
        for (i, &a) in self.words().iter().enumerate() {
            let mut carry = 0u64;
            for (j, &b) in other.words().iter().enumerate() {
                let at = i + j;
                let value = out[at] as u64 + a as u64 * b as u64 + carry;
                out[at] = value as u32;
                carry = value >> 32;
            }
            let mut at = i + other.words().len();
            while carry != 0 {
                let value = out[at] as u64 + carry;
                out[at] = value as u32;
                carry = value >> 32;
                at += 1;
                if at == out.len() && carry != 0 {
                    out.push(0);
                }
            }
        }
        let mut result = Self(out);
        result.normalize();
        result
    }

    pub fn shl(&self, bits: usize) -> Self {
        if self.is_zero() {
            return Self::zero();
        }
        let words = bits / 32;
        let shift = bits % 32;
        let mut out = vec![0u32; words];
        let mut carry = 0u64;
        for &word in self.words() {
            let value = ((word as u64) << shift) | carry;
            out.push(value as u32);
            carry = value >> 32;
        }
        if carry != 0 {
            out.push(carry as u32);
        }
        Self(out)
    }

    pub fn div_rem_u32(&self, divisor: u32) -> (Self, u32) {
        assert_ne!(divisor, 0);
        let mut quotient = vec![0u32; self.words().len()];
        let mut remainder = 0u64;
        for i in (0..self.words().len()).rev() {
            let value = (remainder << 32) | self.0[i] as u64;
            quotient[i] = (value / divisor as u64) as u32;
            remainder = value % divisor as u64;
        }
        let mut result = Self(quotient);
        result.normalize();
        (result, remainder as u32)
    }

    pub fn div_rem_u64(&self, divisor: u64) -> (Self, u64) {
        assert_ne!(divisor, 0);
        let mut quotient = vec![0u32; self.words().len()];
        let mut remainder = 0u128;
        for i in (0..self.words().len()).rev() {
            let value = (remainder << 32) | self.0[i] as u128;
            quotient[i] = (value / divisor as u128) as u32;
            remainder = value % divisor as u128;
        }
        let mut result = Self(quotient);
        result.normalize();
        (result, remainder as u64)
    }

    pub fn to_usize(&self) -> Option<usize> {
        if self.words().len() > (usize::BITS / 32) as usize {
            return None;
        }
        let mut value = 0usize;
        for &word in self.words().iter().rev() {
            value = value.checked_shl(32)?.checked_add(word as usize)?;
        }
        Some(value)
    }

    pub fn to_bytes(&self) -> Vec<u8> {
        let mut out = Vec::with_capacity(self.words().len() * 4);
        for &word in self.words() {
            out.extend_from_slice(&word.to_le_bytes());
        }
        out
    }

    pub fn from_bytes(bytes: &[u8]) -> Result<Self> {
        if bytes.len() % 4 != 0 {
            return Err(FelixError::Invalid("unaligned BigNat".into()));
        }
        let mut words = bytes
            .chunks_exact(4)
            .map(|chunk| u32::from_le_bytes(chunk.try_into().unwrap()))
            .collect::<Vec<_>>();
        while words.last() == Some(&0) {
            words.pop();
        }
        Ok(Self(words))
    }

    pub fn from_decimal(text: &str) -> Result<Self> {
        if text.is_empty() || !text.bytes().all(|byte| byte.is_ascii_digit()) {
            return Err(FelixError::Invalid(format!(
                "invalid unsigned integer {text:?}"
            )));
        }
        let mut value = Self::zero();
        for digit in text.bytes() {
            value = value.mul_u32(10).add_u64((digit - b'0') as u64);
        }
        Ok(value)
    }
}

impl Display for BigNat {
    fn fmt(&self, f: &mut Formatter<'_>) -> std::fmt::Result {
        if self.is_zero() {
            return f.write_str("0");
        }
        let mut value = self.clone();
        let mut groups = Vec::new();
        while !value.is_zero() {
            let (next, remainder) = value.div_rem_u32(1_000_000_000);
            groups.push(remainder);
            value = next;
        }
        write!(f, "{}", groups.pop().unwrap())?;
        while let Some(group) = groups.pop() {
            write!(f, "{group:09}")?;
        }
        Ok(())
    }
}
