use std::{env, fs, path::Path};

use felixfs::{
    FelixError, FelixVolume, Result,
    bignat::BigNat,
    phi::BranchKind,
    sample,
    scanner::{self, GrayImage},
};

fn load(path: &str) -> Result<FelixVolume> {
    FelixVolume::decode(&fs::read_to_string(path)?)
}

fn usage() -> FelixError {
    FelixError::Invalid(
        "usage: felix demo DIR | info PAYLOAD | ls PAYLOAD PATH | read PAYLOAD PATH OFFSET LENGTH OUTPUT | scan BMP OUTPUT | verify PAYLOAD BMP | serve PAYLOAD ADDRESS | mount-windows PAYLOAD ROOT DRIVE | unmount-windows ROOT DRIVE".into()
    )
}

fn run() -> Result<()> {
    let arguments: Vec<String> = env::args().skip(1).collect();
    match arguments.first().map(String::as_str) {
        Some("demo") if arguments.len() == 2 => {
            let directory = Path::new(&arguments[1]);
            fs::create_dir_all(directory)?;
            let volume = sample::volume();
            let payload = volume.encode()?;
            fs::write(directory.join("felix.fx1"), format!("{payload}\n"))?;
            scanner::render(payload.as_bytes()).save_bmp(directory.join("felix-angular.bmp"))?;
            println!("payload_bytes={}", payload.len());
            println!("dimensions={}", volume.lattice.dimensions());
            println!("recursive_levels={}", volume.lattice.levels.len());
            println!("channels={}", volume.lattice.channels);
            println!("logical_bytes={}", volume.lattice.logical_bytes());
        }
        Some("info") if arguments.len() == 2 => {
            let volume = load(&arguments[1])?;
            println!("version={}", volume.version);
            println!("dimensions={}", volume.lattice.dimensions());
            println!("recursive_levels={}", volume.lattice.levels.len());
            println!("channels={}", volume.lattice.channels);
            println!("vm_opcodes={}", felixfs::vm::OPCODE_COUNT);
            println!("vm_instructions={}", volume.evaluator.instructions.len());
            println!("logical_bytes={}", volume.lattice.logical_bytes());
        }
        Some("ls") if arguments.len() == 3 => {
            let volume = load(&arguments[1])?;
            for item in volume.phi.list(&arguments[2])? {
                let kind = if item.kind == BranchKind::Directory {
                    "dir "
                } else {
                    "file"
                };
                println!("{kind}\t{}\t{}", item.length, item.name);
            }
        }
        Some("read") if arguments.len() == 6 => {
            let volume = load(&arguments[1])?;
            let offset = BigNat::from_decimal(&arguments[3])?;
            let length: usize = arguments[4].parse().map_err(|_| usage())?;
            let bytes = volume.read(&arguments[2], &offset, length)?;
            fs::write(&arguments[5], &bytes)?;
            println!("{} bytes", bytes.len());
        }
        Some("scan") if arguments.len() == 3 => {
            let image = GrayImage::load_bmp(&arguments[1])?;
            let payload = scanner::scan(&image)?;
            fs::write(&arguments[2], &payload)?;
            println!("{} bytes", payload.len());
        }
        Some("verify") if arguments.len() == 3 => {
            let expected = fs::read_to_string(&arguments[1])?;
            let image = GrayImage::load_bmp(&arguments[2])?;
            let scanned = scanner::scan(&image)?;
            if scanned != expected.trim().as_bytes() {
                return Err(FelixError::Invalid(
                    "angular scan differs from FX1 payload".into(),
                ));
            }
            FelixVolume::decode(
                std::str::from_utf8(&scanned)
                    .map_err(|_| FelixError::Invalid("scanned payload is not UTF-8".into()))?,
            )?;
            println!("physical angular scan exactly matches and decodes");
        }
        Some("serve") if arguments.len() == 3 => {
            let volume = load(&arguments[1])?;
            println!("FelixFS WebDAV listening on {}", arguments[2]);
            felixfs::webdav::serve(volume, &arguments[2])?;
        }
        #[cfg(windows)]
        Some("mount-windows") if arguments.len() == 4 => {
            let volume = load(&arguments[1])?;
            felixfs::windows_mount::mount(volume, Path::new(&arguments[2]), &arguments[3])?.wait();
        }
        #[cfg(windows)]
        Some("unmount-windows") if arguments.len() == 3 => {
            felixfs::windows_mount::unmount(Path::new(&arguments[1]), &arguments[2])?;
            println!("FelixFS unmounted from {}", arguments[2]);
        }
        _ => return Err(usage()),
    }
    Ok(())
}

fn main() {
    if let Err(error) = run() {
        eprintln!("felix: {error}");
        std::process::exit(1);
    }
}
