use crate::{
    bignat::BigNat,
    error::{FelixError, Result},
};

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Axis {
    pub states: u32,
    pub rotations: u32,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Level {
    pub axes: Vec<Axis>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Lattice {
    pub levels: Vec<Level>,
    pub channels: u32,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Coordinate {
    pub levels: Vec<Vec<u32>>,
    pub channel: u32,
}

impl Lattice {
    pub fn validate(&self) -> Result<()> {
        if self.levels.is_empty() {
            return Err(FelixError::Invalid(
                "lattice needs at least one recursive level".into(),
            ));
        }
        if self.channels == 0 {
            return Err(FelixError::Invalid(
                "lattice needs at least one output channel".into(),
            ));
        }
        for (depth, level) in self.levels.iter().enumerate() {
            if level.axes.is_empty() {
                return Err(FelixError::Invalid(format!("level {depth} has no axes")));
            }
            for (axis, spec) in level.axes.iter().enumerate() {
                if spec.states == 0 || spec.rotations == 0 {
                    return Err(FelixError::Invalid(format!(
                        "level {depth} axis {axis} has an empty state space"
                    )));
                }
            }
        }
        Ok(())
    }

    pub fn dimensions(&self) -> usize {
        self.levels.iter().map(|level| level.axes.len()).sum()
    }

    pub fn points(&self) -> BigNat {
        self.levels
            .iter()
            .flat_map(|level| &level.axes)
            .fold(BigNat::one(), |n, axis| n.mul_u32(axis.states))
    }

    pub fn logical_bytes(&self) -> BigNat {
        self.points().mul_u32(self.channels)
    }

    pub fn address_to_coordinate(&self, address: &BigNat) -> Result<Coordinate> {
        if address >= &self.logical_bytes() {
            return Err(FelixError::OutOfRange(address.to_string()));
        }
        let (mut point, channel) = address.div_rem_u32(self.channels);
        let mut flat = vec![0u32; self.dimensions()];
        let axes: Vec<&Axis> = self.levels.iter().flat_map(|level| &level.axes).collect();
        for index in (0..axes.len()).rev() {
            let (next, remainder) = point.div_rem_u32(axes[index].states);
            flat[index] = remainder;
            point = next;
        }
        debug_assert!(point.is_zero());
        let mut at = 0;
        let levels = self
            .levels
            .iter()
            .map(|level| {
                let next = at + level.axes.len();
                let coordinates = flat[at..next].to_vec();
                at = next;
                coordinates
            })
            .collect();
        Ok(Coordinate { levels, channel })
    }

    pub fn coordinate_to_address(&self, coordinate: &Coordinate) -> Result<BigNat> {
        if coordinate.levels.len() != self.levels.len() || coordinate.channel >= self.channels {
            return Err(FelixError::Invalid(
                "coordinate shape or channel does not match lattice".into(),
            ));
        }
        let mut point = BigNat::zero();
        for (depth, (values, level)) in coordinate.levels.iter().zip(&self.levels).enumerate() {
            if values.len() != level.axes.len() {
                return Err(FelixError::Invalid(format!(
                    "coordinate level {depth} has the wrong rank"
                )));
            }
            for (axis, (&value, spec)) in values.iter().zip(&level.axes).enumerate() {
                if value >= spec.states {
                    return Err(FelixError::OutOfRange(format!(
                        "level {depth} axis {axis}: {value}"
                    )));
                }
                point = point.mul_u32(spec.states).add_u64(value as u64);
            }
        }
        Ok(point
            .mul_u32(self.channels)
            .add_u64(coordinate.channel as u64))
    }

    pub fn flatten<'a>(&self, coordinate: &'a Coordinate) -> impl Iterator<Item = u32> + 'a {
        coordinate.levels.iter().flatten().copied()
    }

    pub fn angles(&self, coordinate: &Coordinate) -> Result<Vec<f64>> {
        self.coordinate_to_address(coordinate)?;
        Ok(coordinate
            .levels
            .iter()
            .zip(&self.levels)
            .flat_map(|(values, level)| {
                values.iter().zip(&level.axes).map(|(&value, axis)| {
                    std::f64::consts::TAU * value as f64 / axis.rotations as f64
                })
            })
            .collect())
    }
}
