use crate::{
    bignat::BigNat,
    error::{FelixError, Result},
    image_geometry::ImageGeometry,
};
use std::sync::Arc;

#[derive(Clone, Debug)]
pub struct AngularWord {
    pub radix: u16,
    pub states: Vec<u16>,
}

impl AngularWord {
    pub fn from_bytes(bytes: &[u8]) -> Self {
        Self {
            radix: 256,
            states: bytes.iter().map(|&value| value as u16).collect(),
        }
    }

    pub fn decode_bytes(&self) -> Result<Vec<u8>> {
        if self.radix < 256
            || self
                .states
                .iter()
                .any(|&state| state >= self.radix || state > 255)
        {
            return Err(FelixError::Invalid(
                "angular word is not byte-decodable".into(),
            ));
        }
        Ok(self.states.iter().map(|&state| state as u8).collect())
    }

    pub fn decode_string(&self) -> Result<String> {
        String::from_utf8(self.decode_bytes()?)
            .map_err(|_| FelixError::Invalid("angular name is not UTF-8".into()))
    }

    pub fn angles(&self) -> Vec<f64> {
        self.states
            .iter()
            .map(|&state| std::f64::consts::TAU * state as f64 / self.radix as f64)
            .collect()
    }
}

#[derive(Clone, Debug)]
pub enum ContentGeometry {
    Angular {
        bytes: AngularWord,
    },
    Lattice {
        start: BigNat,
        length: BigNat,
    },
    Orbit {
        start: BigNat,
        length: BigNat,
        chart_bytes: u64,
        stride: BigNat,
    },
    GeneratedBmp {
        image: Arc<ImageGeometry>,
    },
    ExactFile {
        bytes: Arc<Vec<u8>>,
    },
}

impl ContentGeometry {
    pub fn length(&self) -> BigNat {
        match self {
            Self::Angular { bytes } => BigNat::from(bytes.states.len()),
            Self::Lattice { length, .. } | Self::Orbit { length, .. } => length.clone(),
            Self::GeneratedBmp { image } => BigNat::from(image.bmp_length().unwrap_or(0)),
            Self::ExactFile { bytes } => BigNat::from(bytes.len()),
        }
    }

    pub fn geometric_address(&self, offset: &BigNat) -> Result<Option<BigNat>> {
        if offset >= &self.length() {
            return Err(FelixError::OutOfRange(offset.to_string()));
        }
        Ok(match self {
            Self::Angular { .. } | Self::GeneratedBmp { .. } | Self::ExactFile { .. } => None,
            Self::Lattice { start, .. } => Some(start.add(offset)),
            Self::Orbit {
                start,
                chart_bytes,
                stride,
                ..
            } => {
                let (chart, within) = offset.div_rem_u64(*chart_bytes);
                Some(start.add(&chart.mul(stride)).add_u64(within))
            }
        })
    }
}

#[derive(Clone, Debug)]
pub struct Branch {
    pub rotation_state: u32,
    pub rotation_radix: u32,
    pub name: AngularWord,
    pub content: Option<ContentGeometry>,
    pub children: Vec<Branch>,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum BranchKind {
    Directory,
    File,
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Metadata {
    pub path: String,
    pub name: String,
    pub kind: BranchKind,
    pub length: BigNat,
    pub rotation_state: u32,
    pub rotation_radix: u32,
}

#[derive(Clone, Debug)]
pub struct Phi {
    pub root: Branch,
}

impl Branch {
    pub fn validate(&self, path: &str) -> Result<()> {
        if self.rotation_radix == 0 || self.rotation_state >= self.rotation_radix {
            return Err(FelixError::Invalid(format!(
                "branch {path} has invalid rotation"
            )));
        }
        let name = self.name.decode_string()?;
        if name.contains('/')
            || name.contains('\\')
            || name.contains('|')
            || name.chars().any(char::is_control)
            || name == "."
            || name == ".."
        {
            return Err(FelixError::Invalid(format!(
                "branch {path} has unsafe name {name:?}"
            )));
        }
        if self.content.is_some() && !self.children.is_empty() {
            return Err(FelixError::Invalid(format!(
                "branch {path} is both file and directory"
            )));
        }
        let mut names = std::collections::HashSet::new();
        for child in &self.children {
            let child_name = child.name.decode_string()?;
            if !names.insert(child_name.clone()) {
                return Err(FelixError::Invalid(format!(
                    "duplicate child {child_name:?} at {path}"
                )));
            }
            child.validate(&format!("{path}/{child_name}"))?;
        }
        Ok(())
    }

    pub fn angle(&self) -> f64 {
        std::f64::consts::TAU * self.rotation_state as f64 / self.rotation_radix as f64
    }
}

impl Phi {
    pub fn validate(&self) -> Result<()> {
        if self.root.content.is_some() {
            return Err(FelixError::Invalid(
                "Phi root must be a geometric directory branch".into(),
            ));
        }
        self.root.validate("")
    }

    fn components(path: &str) -> Vec<&str> {
        path.split('/').filter(|part| !part.is_empty()).collect()
    }

    pub fn resolve(&self, path: &str) -> Result<&Branch> {
        let mut branch = &self.root;
        for component in Self::components(path) {
            if branch.content.is_some() {
                return Err(FelixError::NotDirectory(path.into()));
            }
            branch = branch
                .children
                .iter()
                .find(|child| {
                    child
                        .name
                        .decode_string()
                        .is_ok_and(|name| name == component)
                })
                .ok_or_else(|| FelixError::NotFound(path.into()))?;
        }
        Ok(branch)
    }

    pub fn path_states(&self, path: &str) -> Result<Vec<(u32, u32)>> {
        let mut branch = &self.root;
        let mut states = Vec::new();
        for component in Self::components(path) {
            branch = branch
                .children
                .iter()
                .find(|child| {
                    child
                        .name
                        .decode_string()
                        .is_ok_and(|name| name == component)
                })
                .ok_or_else(|| FelixError::NotFound(path.into()))?;
            states.push((branch.rotation_state, branch.rotation_radix));
        }
        Ok(states)
    }

    pub fn metadata(&self, path: &str) -> Result<Metadata> {
        let branch = self.resolve(path)?;
        Ok(Metadata {
            path: normalize_path(path),
            name: branch.name.decode_string()?,
            kind: if branch.content.is_some() {
                BranchKind::File
            } else {
                BranchKind::Directory
            },
            length: branch
                .content
                .as_ref()
                .map_or_else(BigNat::zero, ContentGeometry::length),
            rotation_state: branch.rotation_state,
            rotation_radix: branch.rotation_radix,
        })
    }

    pub fn list(&self, path: &str) -> Result<Vec<Metadata>> {
        let branch = self.resolve(path)?;
        if branch.content.is_some() {
            return Err(FelixError::NotDirectory(path.into()));
        }
        branch
            .children
            .iter()
            .map(|child| {
                let name = child.name.decode_string()?;
                self.metadata(&format!("{}/{}", normalize_path(path), name))
            })
            .collect()
    }

    pub fn direct_byte(&self, path: &str, offset: &BigNat) -> Result<Option<u8>> {
        let branch = self.resolve(path)?;
        let content = branch
            .content
            .as_ref()
            .ok_or_else(|| FelixError::IsDirectory(path.into()))?;
        match content {
            ContentGeometry::Angular { bytes } => {
                let index = offset
                    .to_usize()
                    .ok_or_else(|| FelixError::OutOfRange(offset.to_string()))?;
                Ok(Some(*bytes.decode_bytes()?.get(index).ok_or_else(
                    || FelixError::OutOfRange(offset.to_string()),
                )?))
            }
            ContentGeometry::GeneratedBmp { image } => {
                let index = offset
                    .to_u64()
                    .ok_or_else(|| FelixError::OutOfRange(offset.to_string()))?;
                Ok(Some(image.byte(index)?))
            }
            ContentGeometry::ExactFile { bytes } => {
                let index = offset
                    .to_usize()
                    .ok_or_else(|| FelixError::OutOfRange(offset.to_string()))?;
                Ok(Some(*bytes.get(index).ok_or_else(|| {
                    FelixError::OutOfRange(offset.to_string())
                })?))
            }
            _ => Ok(None),
        }
    }
}

fn normalize_path(path: &str) -> String {
    let components = Phi::components(path);
    if components.is_empty() {
        "/".into()
    } else {
        format!("/{}", components.join("/"))
    }
}
