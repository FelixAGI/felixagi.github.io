use crate::{
    bignat::BigNat,
    lattice::{Axis, Lattice, Level},
    phi::{AngularWord, Branch, ContentGeometry, Phi},
    vm::{Instruction, Program},
    volume::FelixVolume,
};

fn word(value: &str) -> AngularWord {
    AngularWord::from_bytes(value.as_bytes())
}

fn directory(state: u32, name: &str, children: Vec<Branch>) -> Branch {
    Branch {
        rotation_state: state,
        rotation_radix: 256,
        name: word(name),
        content: None,
        children,
    }
}

fn angular_file(state: u32, name: &str, bytes: &[u8]) -> Branch {
    Branch {
        rotation_state: state,
        rotation_radix: 256,
        name: word(name),
        content: Some(ContentGeometry::Angular {
            bytes: AngularWord::from_bytes(bytes),
        }),
        children: vec![],
    }
}

fn lattice_file(state: u32, name: &str, start: BigNat, length: BigNat) -> Branch {
    Branch {
        rotation_state: state,
        rotation_radix: 256,
        name: word(name),
        content: Some(ContentGeometry::Lattice { start, length }),
        children: vec![],
    }
}

fn orbit_file(
    state: u32,
    name: &str,
    start: BigNat,
    length: BigNat,
    chart_bytes: u64,
    stride: BigNat,
) -> Branch {
    Branch {
        rotation_state: state,
        rotation_radix: 256,
        name: word(name),
        content: Some(ContentGeometry::Orbit {
            start,
            length,
            chart_bytes,
            stride,
        }),
        children: vec![],
    }
}

fn evaluator(dimensions: usize, channels: u32) -> Program {
    use Instruction::*;
    let mut instructions = vec![Const {
        value: 0x9e37_79b9_7f4a_7c15,
    }];
    let mut hash = 0usize;
    for axis in 0..dimensions {
        let coordinate = instructions.len();
        instructions.push(Coord { axis });
        let coefficient = instructions.len();
        instructions.push(Const {
            value: 0x1000_0000_01b3u64.wrapping_add((axis as u64) * 0x9e37),
        });
        let product = instructions.len();
        instructions.push(Mul {
            a: coordinate,
            b: coefficient,
        });
        let combined = instructions.len();
        instructions.push(Xor {
            a: hash,
            b: product,
        });
        hash = instructions.len();
        instructions.push(Mix64 { a: combined });
    }
    let channel = instructions.len();
    instructions.push(Channel);
    let channel_mix = instructions.len();
    instructions.push(Mix64 { a: channel });
    let combined = instructions.len();
    instructions.push(Xor {
        a: hash,
        b: channel_mix,
    });
    let final_hash = instructions.len();
    instructions.push(Mix64 { a: combined });

    let mut outputs = Vec::new();
    for channel_index in 0..channels {
        let shift = instructions.len();
        instructions.push(Const {
            value: (channel_index * 8) as u64,
        });
        let output = instructions.len();
        instructions.push(RotateRight {
            a: final_hash,
            b: shift,
        });
        outputs.push(output);
    }
    Program {
        instructions,
        outputs,
    }
}

pub fn volume() -> FelixVolume {
    let levels = (0..3)
        .map(|_| Level {
            axes: (0..8)
                .map(|_| Axis {
                    states: 16,
                    rotations: 16,
                })
                .collect(),
        })
        .collect();
    let lattice = Lattice {
        levels,
        channels: 4,
    };
    let tib = BigNat::one().shl(40);
    let mib = BigNat::one().shl(20);
    let readme = b"FelixFS\n\nThis mounted volume is a recursive geometric object.\nPaths, metadata, and file bytes are decoded from angular states.\n";

    let phi = Phi {
        root: directory(
            0,
            "",
            vec![
                angular_file(17, "README.txt", readme),
                lattice_file(31, "lattice.bin", BigNat::zero(), tib.clone()),
                directory(
                    47,
                    "recursive",
                    vec![
                        orbit_file(
                            61,
                            "level-0.bin",
                            tib.clone(),
                            mib.clone(),
                            4096,
                            BigNat::from(65537u32),
                        ),
                        orbit_file(
                            79,
                            "level-1.bin",
                            tib.add(&mib.mul_u32(17)),
                            mib.clone(),
                            8192,
                            BigNat::from(131101u32),
                        ),
                        directory(
                            103,
                            "nested",
                            vec![lattice_file(
                                127,
                                "twenty-four-dimensions.bin",
                                tib.mul_u32(2),
                                mib,
                            )],
                        ),
                    ],
                ),
            ],
        ),
    };

    FelixVolume {
        version: 1,
        evaluator: evaluator(lattice.dimensions(), lattice.channels),
        lattice,
        phi,
    }
}
