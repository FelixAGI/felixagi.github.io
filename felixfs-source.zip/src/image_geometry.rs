use std::sync::Arc;

use crate::{
    error::{FelixError, Result},
    lattice::{Axis, Lattice, Level},
    phi::{AngularWord, Branch, ContentGeometry, Phi},
    vm::{Instruction, Program},
    volume::FelixVolume,
};

#[derive(Clone, Debug)]
enum Node {
    Leaf([u8; 3]),
    SplitX { first: usize, second: usize },
    SplitY { first: usize, second: usize },
}

#[derive(Clone, Debug)]
pub struct ImageGeometry {
    original_width: u16,
    original_height: u16,
    model_width: u16,
    model_height: u16,
    repeat_count: u16,
    leaf_count: u16,
    nodes: Vec<Node>,
    root: usize,
}

#[derive(Clone, Debug)]
pub struct ExactFileSet {
    name: String,
    repeat_count: u16,
    bytes: Arc<Vec<u8>>,
}

impl ExactFileSet {
    pub fn from_binary(binary: &[u8]) -> Result<Self> {
        if binary.get(..4) != Some(b"FQX1") || binary.len() < 16 {
            return Err(FelixError::Invalid("missing FQX1 binary header".into()));
        }
        let repeat_count = u16::from_le_bytes([binary[4], binary[5]]);
        let name_length = u16::from_le_bytes([binary[6], binary[7]]) as usize;
        let file_length = u64::from_le_bytes(binary[8..16].try_into().unwrap());
        let file_length: usize = file_length
            .try_into()
            .map_err(|_| FelixError::Invalid("FQX1 file exceeds this platform".into()))?;
        let content_at = 16usize
            .checked_add(name_length)
            .ok_or_else(|| FelixError::Invalid("FQX1 name size overflow".into()))?;
        let expected = content_at
            .checked_add(file_length)
            .ok_or_else(|| FelixError::Invalid("FQX1 file size overflow".into()))?;
        if repeat_count == 0 || name_length == 0 || binary.len() != expected {
            return Err(FelixError::Invalid("FQX1 record shape is invalid".into()));
        }
        let name = std::str::from_utf8(&binary[16..content_at])
            .map_err(|_| FelixError::Invalid("FQX1 filename is not UTF-8".into()))?
            .to_owned();
        if name.contains('/')
            || name.contains('\\')
            || name.contains('|')
            || name.chars().any(char::is_control)
            || name == "."
            || name == ".."
        {
            return Err(FelixError::Invalid("FQX1 filename is unsafe".into()));
        }
        Ok(Self {
            name,
            repeat_count,
            bytes: Arc::new(binary[content_at..].to_vec()),
        })
    }

    pub fn into_volume(self) -> FelixVolume {
        let (stem, extension) = self
            .name
            .rsplit_once('.')
            .map_or((self.name.as_str(), ""), |parts| parts);
        let width = usize::from(self.repeat_count).to_string().len().max(4);
        let files = (1..=self.repeat_count)
            .map(|index| {
                let name = if extension.is_empty() {
                    format!("{stem}-{index:0width$}")
                } else {
                    format!("{stem}-{index:0width$}.{extension}")
                };
                Branch {
                    rotation_state: u32::from(index) % 256,
                    rotation_radix: 256,
                    name: AngularWord::from_bytes(name.as_bytes()),
                    content: Some(ContentGeometry::ExactFile {
                        bytes: Arc::clone(&self.bytes),
                    }),
                    children: vec![],
                }
            })
            .collect();
        let readme = format!(
            "FelixFS exact repeated-file volume\n\n{} files reproduce {} byte-for-byte from one shared source.\n",
            self.repeat_count, self.name
        );
        base_volume(vec![
            Branch {
                rotation_state: 17,
                rotation_radix: 256,
                name: AngularWord::from_bytes(b"README.txt"),
                content: Some(ContentGeometry::Angular {
                    bytes: AngularWord::from_bytes(readme.as_bytes()),
                }),
                children: vec![],
            },
            Branch {
                rotation_state: 73,
                rotation_radix: 256,
                name: AngularWord::from_bytes(b"files"),
                content: None,
                children: files,
            },
        ])
    }
}

impl ImageGeometry {
    pub fn from_binary(bytes: &[u8]) -> Result<Self> {
        if bytes.get(..4) != Some(b"FQI1") || bytes.len() < 16 {
            return Err(FelixError::Invalid("missing FQI1 binary header".into()));
        }
        let read_u16 = |at: usize| u16::from_le_bytes([bytes[at], bytes[at + 1]]);
        let original_width = read_u16(4);
        let original_height = read_u16(6);
        let model_width = read_u16(8);
        let model_height = read_u16(10);
        let repeat_count = read_u16(12);
        let leaf_count = read_u16(14);
        if original_width == 0
            || original_height == 0
            || model_width == 0
            || model_height == 0
            || repeat_count == 0
            || leaf_count == 0
        {
            return Err(FelixError::Invalid(
                "FQI1 dimensions, repeats, and leaves must be nonzero".into(),
            ));
        }

        let node_count = usize::from(leaf_count)
            .checked_mul(2)
            .and_then(|value| value.checked_sub(1))
            .ok_or_else(|| FelixError::Invalid("FQI1 node count overflow".into()))?;
        let token_length = node_count
            .checked_mul(2)
            .and_then(|bits| bits.checked_add(7))
            .map(|bits| bits / 8)
            .ok_or_else(|| FelixError::Invalid("FQI1 token size overflow".into()))?;
        let color_length = usize::from(leaf_count) * 3;
        let expected = 16usize
            .checked_add(token_length)
            .and_then(|value| value.checked_add(color_length))
            .ok_or_else(|| FelixError::Invalid("FQI1 record size overflow".into()))?;
        if bytes.len() != expected {
            return Err(FelixError::Invalid(format!(
                "FQI1 record has {} bytes; expected {expected}",
                bytes.len()
            )));
        }

        let tokens = &bytes[16..16 + token_length];
        let colors = &bytes[16 + token_length..];
        let mut parser = TreeParser {
            tokens,
            colors,
            node_count,
            token_at: 0,
            color_at: 0,
            nodes: Vec::with_capacity(node_count),
        };
        let root = parser.node(usize::from(model_width), usize::from(model_height), 0)?;
        if parser.token_at != node_count
            || parser.color_at != colors.len()
            || parser.nodes.len() != node_count
        {
            return Err(FelixError::Invalid("FQI1 tree is incomplete".into()));
        }

        let image = Self {
            original_width,
            original_height,
            model_width,
            model_height,
            repeat_count,
            leaf_count,
            nodes: parser.nodes,
            root,
        };
        image.bmp_length()?;
        Ok(image)
    }

    pub fn repeat_count(&self) -> u16 {
        self.repeat_count
    }

    pub fn leaf_count(&self) -> u16 {
        self.leaf_count
    }

    pub fn bmp_length(&self) -> Result<u64> {
        let pixels = self
            .row_bytes()
            .checked_mul(u64::from(self.original_height))
            .ok_or_else(|| FelixError::Invalid("generated BMP size overflow".into()))?;
        let length = 54u64
            .checked_add(pixels)
            .ok_or_else(|| FelixError::Invalid("generated BMP size overflow".into()))?;
        u32::try_from(length)
            .map(u64::from)
            .map_err(|_| FelixError::Invalid("generated BMP exceeds the BMP size limit".into()))
    }

    pub fn byte(&self, offset: u64) -> Result<u8> {
        let length = self.bmp_length()?;
        if offset >= length {
            return Err(FelixError::OutOfRange(offset.to_string()));
        }
        if offset < 54 {
            return Ok(self.bmp_header()?[offset as usize]);
        }

        let pixel_offset = offset - 54;
        let row_bytes = self.row_bytes();
        let file_row = pixel_offset / row_bytes;
        let within_row = pixel_offset % row_bytes;
        let packed_row = u64::from(self.original_width) * 3;
        if within_row >= packed_row {
            return Ok(0);
        }
        let x = within_row / 3;
        let channel = within_row % 3;
        let y = u64::from(self.original_height) - 1 - file_row;
        let model_x = x * u64::from(self.model_width) / u64::from(self.original_width);
        let model_y = y * u64::from(self.model_height) / u64::from(self.original_height);
        let rgb = self.color_at(model_x as usize, model_y as usize);
        Ok(match channel {
            0 => rgb[2],
            1 => rgb[1],
            _ => rgb[0],
        })
    }

    pub fn into_volume(self) -> FelixVolume {
        let repeat_count = self.repeat_count;
        let image = Arc::new(self);
        let width = usize::from(repeat_count).to_string().len().max(4);
        let files = (1..=repeat_count)
            .map(|index| Branch {
                rotation_state: u32::from(index) % 256,
                rotation_radix: 256,
                name: AngularWord::from_bytes(format!("image-{index:0width$}.bmp").as_bytes()),
                content: Some(ContentGeometry::GeneratedBmp {
                    image: Arc::clone(&image),
                }),
                children: vec![],
            })
            .collect();
        let readme = format!(
            "FelixFS generated image volume\n\n{} BMP files are decoded lazily from one FQI1 geometry with {} adaptive regions.\n",
            repeat_count,
            image.leaf_count()
        );
        let root = Branch {
            rotation_state: 0,
            rotation_radix: 256,
            name: AngularWord::from_bytes(b""),
            content: None,
            children: vec![
                Branch {
                    rotation_state: 17,
                    rotation_radix: 256,
                    name: AngularWord::from_bytes(b"README.txt"),
                    content: Some(ContentGeometry::Angular {
                        bytes: AngularWord::from_bytes(readme.as_bytes()),
                    }),
                    children: vec![],
                },
                Branch {
                    rotation_state: 73,
                    rotation_radix: 256,
                    name: AngularWord::from_bytes(b"images"),
                    content: None,
                    children: files,
                },
            ],
        };
        base_volume(root.children)
    }

    fn row_bytes(&self) -> u64 {
        (u64::from(self.original_width) * 3 + 3) & !3
    }

    fn bmp_header(&self) -> Result<[u8; 54]> {
        let mut header = [0u8; 54];
        let file_size = self.bmp_length()? as u32;
        let pixel_size = (self.row_bytes() * u64::from(self.original_height)) as u32;
        header[0..2].copy_from_slice(b"BM");
        header[2..6].copy_from_slice(&file_size.to_le_bytes());
        header[10..14].copy_from_slice(&54u32.to_le_bytes());
        header[14..18].copy_from_slice(&40u32.to_le_bytes());
        header[18..22].copy_from_slice(&u32::from(self.original_width).to_le_bytes());
        header[22..26].copy_from_slice(&u32::from(self.original_height).to_le_bytes());
        header[26..28].copy_from_slice(&1u16.to_le_bytes());
        header[28..30].copy_from_slice(&24u16.to_le_bytes());
        header[34..38].copy_from_slice(&pixel_size.to_le_bytes());
        header[38..42].copy_from_slice(&2835u32.to_le_bytes());
        header[42..46].copy_from_slice(&2835u32.to_le_bytes());
        Ok(header)
    }

    fn color_at(&self, mut x: usize, mut y: usize) -> [u8; 3] {
        let mut width = usize::from(self.model_width);
        let mut height = usize::from(self.model_height);
        let mut at = self.root;
        loop {
            match self.nodes[at] {
                Node::Leaf(rgb) => return rgb,
                Node::SplitX { first, second } => {
                    let split = width / 2;
                    if x < split {
                        at = first;
                        width = split;
                    } else {
                        at = second;
                        x -= split;
                        width -= split;
                    }
                }
                Node::SplitY { first, second } => {
                    let split = height / 2;
                    if y < split {
                        at = first;
                        height = split;
                    } else {
                        at = second;
                        y -= split;
                        height -= split;
                    }
                }
            }
        }
    }
}

fn base_volume(children: Vec<Branch>) -> FelixVolume {
    FelixVolume {
        version: 1,
        lattice: Lattice {
            levels: vec![Level {
                axes: vec![Axis {
                    states: 1,
                    rotations: 1,
                }],
            }],
            channels: 1,
        },
        evaluator: Program {
            instructions: vec![Instruction::Const { value: 0 }],
            outputs: vec![0],
        },
        phi: Phi {
            root: Branch {
                rotation_state: 0,
                rotation_radix: 256,
                name: AngularWord::from_bytes(b""),
                content: None,
                children,
            },
        },
    }
}

struct TreeParser<'a> {
    tokens: &'a [u8],
    colors: &'a [u8],
    node_count: usize,
    token_at: usize,
    color_at: usize,
    nodes: Vec<Node>,
}

impl TreeParser<'_> {
    fn node(&mut self, width: usize, height: usize, depth: usize) -> Result<usize> {
        if depth > 128 || self.token_at >= self.node_count {
            return Err(FelixError::Invalid(
                "FQI1 tree is too deep or truncated".into(),
            ));
        }
        let token = (self.tokens[self.token_at / 4] >> ((self.token_at % 4) * 2)) & 3;
        self.token_at += 1;
        let node = match token {
            0 => {
                let end = self.color_at + 3;
                let color = self
                    .colors
                    .get(self.color_at..end)
                    .ok_or_else(|| FelixError::Invalid("FQI1 color table is truncated".into()))?;
                self.color_at = end;
                Node::Leaf([color[0], color[1], color[2]])
            }
            1 if width >= 2 => {
                let split = width / 2;
                let first = self.node(split, height, depth + 1)?;
                let second = self.node(width - split, height, depth + 1)?;
                Node::SplitX { first, second }
            }
            2 if height >= 2 => {
                let split = height / 2;
                let first = self.node(width, split, depth + 1)?;
                let second = self.node(width, height - split, depth + 1)?;
                Node::SplitY { first, second }
            }
            1 | 2 => {
                return Err(FelixError::Invalid(
                    "FQI1 tree splits a one-pixel region".into(),
                ));
            }
            _ => return Err(FelixError::Invalid("FQI1 tree has an invalid token".into())),
        };
        let index = self.nodes.len();
        self.nodes.push(node);
        Ok(index)
    }
}
