use crate::{
    bignat::BigNat,
    error::{FelixError, Result},
    image_geometry::{ExactFileSet, ImageGeometry},
    lattice::{Axis, Lattice, Level},
    phi::{AngularWord, Branch, ContentGeometry, Phi},
    vm::{Instruction, Program},
};

#[derive(Clone, Debug)]
pub struct FelixVolume {
    pub version: u32,
    pub lattice: Lattice,
    pub evaluator: Program,
    pub phi: Phi,
}

impl FelixVolume {
    pub fn validate(&self) -> Result<()> {
        if self.version != 1 {
            return Err(FelixError::Invalid(format!(
                "unsupported Felix version {}",
                self.version
            )));
        }
        self.lattice.validate()?;
        self.evaluator.validate(&self.lattice)?;
        self.phi.validate()?;
        self.validate_branch(&self.phi.root, "/")
    }

    fn validate_branch(&self, branch: &Branch, path: &str) -> Result<()> {
        if let Some(content) = &branch.content {
            let length = content.length();
            if !length.is_zero() {
                match content {
                    ContentGeometry::Angular { bytes } => {
                        bytes.decode_bytes()?;
                    }
                    ContentGeometry::GeneratedBmp { image } => {
                        image.bmp_length()?;
                    }
                    ContentGeometry::ExactFile { .. } => {}
                    _ => {
                        let final_address = content
                            .geometric_address(&length.sub(&BigNat::one())?)?
                            .unwrap();
                        if final_address >= self.lattice.logical_bytes() {
                            return Err(FelixError::Invalid(format!(
                                "file {path} leaves the geometric lattice at address {final_address}"
                            )));
                        }
                    }
                }
            }
        }
        for child in &branch.children {
            let name = child.name.decode_string()?;
            self.validate_branch(child, &format!("{path}{name}/"))?;
        }
        Ok(())
    }

    pub fn read_geometry(&self, address: &BigNat) -> Result<u8> {
        let coordinate = self.lattice.address_to_coordinate(address)?;
        self.evaluator.evaluate(&self.lattice, &coordinate)
    }

    pub fn read(&self, path: &str, offset: &BigNat, length: usize) -> Result<Vec<u8>> {
        let branch = self.phi.resolve(path)?;
        let content = branch
            .content
            .as_ref()
            .ok_or_else(|| FelixError::IsDirectory(path.into()))?;
        let file_length = content.length();
        if offset > &file_length {
            return Err(FelixError::OutOfRange(offset.to_string()));
        }
        let available = file_length.sub(offset)?;
        let count = available.to_usize().map_or(length, |n| n.min(length));
        match content {
            ContentGeometry::Angular { bytes } => {
                let start = offset
                    .to_usize()
                    .ok_or_else(|| FelixError::OutOfRange(offset.to_string()))?;
                let bytes = bytes.decode_bytes()?;
                return Ok(bytes[start..start + count].to_vec());
            }
            ContentGeometry::ExactFile { bytes } => {
                let start = offset
                    .to_usize()
                    .ok_or_else(|| FelixError::OutOfRange(offset.to_string()))?;
                return Ok(bytes[start..start + count].to_vec());
            }
            ContentGeometry::GeneratedBmp { image } => {
                let start = offset
                    .to_u64()
                    .ok_or_else(|| FelixError::OutOfRange(offset.to_string()))?;
                return (0..count)
                    .map(|index| image.byte(start + index as u64))
                    .collect();
            }
            ContentGeometry::Lattice { .. } | ContentGeometry::Orbit { .. } => {}
        }
        let mut output = Vec::with_capacity(count);
        for index in 0..count {
            let position = offset.add_u64(index as u64);
            let address = content.geometric_address(&position)?.unwrap();
            output.push(self.read_geometry(&address)?);
        }
        Ok(output)
    }

    pub fn to_binary(&self) -> Result<Vec<u8>> {
        self.validate()?;
        let mut writer = Writer::new();
        writer.bytes(b"FXB1");
        writer.var(self.version as u64);
        writer.var(self.lattice.levels.len() as u64);
        for level in &self.lattice.levels {
            writer.var(level.axes.len() as u64);
            for axis in &level.axes {
                writer.var(axis.states as u64);
                writer.var(axis.rotations as u64);
            }
        }
        writer.var(self.lattice.channels as u64);
        put_program(&mut writer, &self.evaluator);
        put_branch(&mut writer, &self.phi.root)?;
        Ok(writer.finish())
    }

    pub fn from_binary(bytes: &[u8]) -> Result<Self> {
        let mut reader = Reader::new(bytes);
        if reader.take(4)? != b"FXB1" {
            return Err(FelixError::Invalid("missing FXB1 header".into()));
        }
        let version = reader.u32()?;
        let level_count = reader.usize()?;
        let mut levels = Vec::with_capacity(level_count);
        for _ in 0..level_count {
            let axis_count = reader.usize()?;
            let mut axes = Vec::with_capacity(axis_count);
            for _ in 0..axis_count {
                axes.push(Axis {
                    states: reader.u32()?,
                    rotations: reader.u32()?,
                });
            }
            levels.push(Level { axes });
        }
        let channels = reader.u32()?;
        let evaluator = get_program(&mut reader)?;
        let root = get_branch(&mut reader)?;
        if !reader.done() {
            return Err(FelixError::Invalid("trailing bytes in FXB1 record".into()));
        }
        let volume = Self {
            version,
            lattice: Lattice { levels, channels },
            evaluator,
            phi: Phi { root },
        };
        volume.validate()?;
        Ok(volume)
    }

    pub fn encode(&self) -> Result<String> {
        let binary = self.to_binary()?;
        Ok(format!(
            "FX1|{}|{:08x}",
            base64url_encode(&binary),
            crc32(&binary)
        ))
    }

    pub fn decode(payload: &str) -> Result<Self> {
        let mut fields = payload.trim().split('|');
        let prefix = fields.next();
        if prefix != Some("FX1") && prefix != Some("FQI1") && prefix != Some("FQX1") {
            return Err(FelixError::Invalid(
                "missing FX1, FQI1, or FQX1 prefix".into(),
            ));
        }
        let body = fields
            .next()
            .ok_or_else(|| FelixError::Invalid("missing FX1 body".into()))?;
        let checksum = fields
            .next()
            .ok_or_else(|| FelixError::Invalid("missing FX1 checksum".into()))?;
        if fields.next().is_some() {
            return Err(FelixError::Invalid("unexpected Felix payload field".into()));
        }
        let binary = base64url_decode(body)?;
        if format!("{:08x}", crc32(&binary)) != checksum {
            return Err(FelixError::Invalid(
                "Felix payload checksum mismatch".into(),
            ));
        }
        if prefix == Some("FQI1") {
            let volume = ImageGeometry::from_binary(&binary)?.into_volume();
            volume.validate()?;
            Ok(volume)
        } else if prefix == Some("FQX1") {
            let volume = ExactFileSet::from_binary(&binary)?.into_volume();
            volume.validate()?;
            Ok(volume)
        } else {
            Self::from_binary(&binary)
        }
    }
}

struct Writer {
    bytes: Vec<u8>,
}

impl Writer {
    fn new() -> Self {
        Self { bytes: Vec::new() }
    }
    fn finish(self) -> Vec<u8> {
        self.bytes
    }
    fn byte(&mut self, value: u8) {
        self.bytes.push(value);
    }
    fn bytes(&mut self, bytes: &[u8]) {
        self.bytes.extend_from_slice(bytes);
    }
    fn var(&mut self, mut value: u64) {
        while value >= 128 {
            self.byte((value as u8 & 127) | 128);
            value >>= 7;
        }
        self.byte(value as u8);
    }
    fn big(&mut self, value: &BigNat) {
        let bytes = value.to_bytes();
        self.var(bytes.len() as u64);
        self.bytes(&bytes);
    }
    fn word(&mut self, word: &AngularWord) {
        self.var(word.radix as u64);
        self.var(word.states.len() as u64);
        for &state in &word.states {
            self.var(state as u64);
        }
    }
}

struct Reader<'a> {
    bytes: &'a [u8],
    at: usize,
}

impl<'a> Reader<'a> {
    fn new(bytes: &'a [u8]) -> Self {
        Self { bytes, at: 0 }
    }
    fn done(&self) -> bool {
        self.at == self.bytes.len()
    }
    fn take(&mut self, count: usize) -> Result<&'a [u8]> {
        let end = self
            .at
            .checked_add(count)
            .ok_or_else(|| FelixError::Invalid("record offset overflow".into()))?;
        let out = self
            .bytes
            .get(self.at..end)
            .ok_or_else(|| FelixError::Invalid("truncated FXB1 record".into()))?;
        self.at = end;
        Ok(out)
    }
    fn byte(&mut self) -> Result<u8> {
        Ok(self.take(1)?[0])
    }
    fn var(&mut self) -> Result<u64> {
        let mut value = 0u64;
        for shift in (0..=63).step_by(7) {
            let byte = self.byte()?;
            value |= ((byte & 127) as u64)
                .checked_shl(shift)
                .ok_or_else(|| FelixError::Invalid("varint overflow".into()))?;
            if byte & 128 == 0 {
                return Ok(value);
            }
        }
        Err(FelixError::Invalid("varint overflow".into()))
    }
    fn u32(&mut self) -> Result<u32> {
        self.var()?
            .try_into()
            .map_err(|_| FelixError::Invalid("integer exceeds u32".into()))
    }
    fn usize(&mut self) -> Result<usize> {
        self.var()?
            .try_into()
            .map_err(|_| FelixError::Invalid("integer exceeds usize".into()))
    }
    fn big(&mut self) -> Result<BigNat> {
        let count = self.usize()?;
        BigNat::from_bytes(self.take(count)?)
    }
    fn word(&mut self) -> Result<AngularWord> {
        let radix = self
            .var()?
            .try_into()
            .map_err(|_| FelixError::Invalid("angular radix exceeds u16".into()))?;
        let count = self.usize()?;
        let mut states = Vec::with_capacity(count);
        for _ in 0..count {
            states.push(
                self.var()?
                    .try_into()
                    .map_err(|_| FelixError::Invalid("angular state exceeds u16".into()))?,
            );
        }
        Ok(AngularWord { radix, states })
    }
}

fn put_program(writer: &mut Writer, program: &Program) {
    writer.var(program.instructions.len() as u64);
    for instruction in &program.instructions {
        put_instruction(writer, instruction);
    }
    writer.var(program.outputs.len() as u64);
    for &output in &program.outputs {
        writer.var(output as u64);
    }
}

fn get_program(reader: &mut Reader<'_>) -> Result<Program> {
    let count = reader.usize()?;
    let mut instructions = Vec::with_capacity(count);
    for _ in 0..count {
        instructions.push(get_instruction(reader)?);
    }
    let count = reader.usize()?;
    let mut outputs = Vec::with_capacity(count);
    for _ in 0..count {
        outputs.push(reader.usize()?);
    }
    Ok(Program {
        instructions,
        outputs,
    })
}

fn put_instruction(writer: &mut Writer, instruction: &Instruction) {
    use Instruction::*;
    let pair = |writer: &mut Writer, tag, a, b| {
        writer.byte(tag);
        writer.var(a as u64);
        writer.var(b as u64);
    };
    match *instruction {
        Const { value } => {
            writer.byte(0);
            writer.var(value);
        }
        Coord { axis } => {
            writer.byte(1);
            writer.var(axis as u64);
        }
        LevelCoord { level, axis } => pair(writer, 2, level, axis),
        Channel => writer.byte(3),
        DimensionCount => writer.byte(4),
        LevelCount => writer.byte(5),
        Add { a, b } => pair(writer, 6, a, b),
        Sub { a, b } => pair(writer, 7, a, b),
        Mul { a, b } => pair(writer, 8, a, b),
        Div { a, b } => pair(writer, 9, a, b),
        Mod { a, b } => pair(writer, 10, a, b),
        Xor { a, b } => pair(writer, 11, a, b),
        And { a, b } => pair(writer, 12, a, b),
        Or { a, b } => pair(writer, 13, a, b),
        Not { a } => {
            writer.byte(14);
            writer.var(a as u64);
        }
        ShiftLeft { a, b } => pair(writer, 15, a, b),
        ShiftRight { a, b } => pair(writer, 16, a, b),
        RotateLeft { a, b } => pair(writer, 17, a, b),
        RotateRight { a, b } => pair(writer, 18, a, b),
        Min { a, b } => pair(writer, 19, a, b),
        Max { a, b } => pair(writer, 20, a, b),
        Equal { a, b } => pair(writer, 21, a, b),
        Less { a, b } => pair(writer, 22, a, b),
        Greater { a, b } => pair(writer, 23, a, b),
        Select { condition, yes, no } => {
            writer.byte(24);
            writer.var(condition as u64);
            writer.var(yes as u64);
            writer.var(no as u64);
        }
        ByteSwap { a } => {
            writer.byte(25);
            writer.var(a as u64);
        }
        PopCount { a } => {
            writer.byte(26);
            writer.var(a as u64);
        }
        Mix64 { a } => {
            writer.byte(27);
            writer.var(a as u64);
        }
    }
}

fn get_instruction(reader: &mut Reader<'_>) -> Result<Instruction> {
    use Instruction::*;
    let tag = reader.byte()?;
    let pair = |reader: &mut Reader<'_>| Ok::<_, FelixError>((reader.usize()?, reader.usize()?));
    Ok(match tag {
        0 => Const {
            value: reader.var()?,
        },
        1 => Coord {
            axis: reader.usize()?,
        },
        2 => {
            let (level, axis) = pair(reader)?;
            LevelCoord { level, axis }
        }
        3 => Channel,
        4 => DimensionCount,
        5 => LevelCount,
        6 => {
            let (a, b) = pair(reader)?;
            Add { a, b }
        }
        7 => {
            let (a, b) = pair(reader)?;
            Sub { a, b }
        }
        8 => {
            let (a, b) = pair(reader)?;
            Mul { a, b }
        }
        9 => {
            let (a, b) = pair(reader)?;
            Div { a, b }
        }
        10 => {
            let (a, b) = pair(reader)?;
            Mod { a, b }
        }
        11 => {
            let (a, b) = pair(reader)?;
            Xor { a, b }
        }
        12 => {
            let (a, b) = pair(reader)?;
            And { a, b }
        }
        13 => {
            let (a, b) = pair(reader)?;
            Or { a, b }
        }
        14 => Not { a: reader.usize()? },
        15 => {
            let (a, b) = pair(reader)?;
            ShiftLeft { a, b }
        }
        16 => {
            let (a, b) = pair(reader)?;
            ShiftRight { a, b }
        }
        17 => {
            let (a, b) = pair(reader)?;
            RotateLeft { a, b }
        }
        18 => {
            let (a, b) = pair(reader)?;
            RotateRight { a, b }
        }
        19 => {
            let (a, b) = pair(reader)?;
            Min { a, b }
        }
        20 => {
            let (a, b) = pair(reader)?;
            Max { a, b }
        }
        21 => {
            let (a, b) = pair(reader)?;
            Equal { a, b }
        }
        22 => {
            let (a, b) = pair(reader)?;
            Less { a, b }
        }
        23 => {
            let (a, b) = pair(reader)?;
            Greater { a, b }
        }
        24 => Select {
            condition: reader.usize()?,
            yes: reader.usize()?,
            no: reader.usize()?,
        },
        25 => ByteSwap { a: reader.usize()? },
        26 => PopCount { a: reader.usize()? },
        27 => Mix64 { a: reader.usize()? },
        _ => return Err(FelixError::Invalid(format!("unknown VM opcode {tag}"))),
    })
}

fn put_branch(writer: &mut Writer, branch: &Branch) -> Result<()> {
    writer.var(branch.rotation_state as u64);
    writer.var(branch.rotation_radix as u64);
    writer.word(&branch.name);
    match &branch.content {
        None => writer.byte(0),
        Some(ContentGeometry::Angular { bytes }) => {
            writer.byte(1);
            writer.word(bytes);
        }
        Some(ContentGeometry::Lattice { start, length }) => {
            writer.byte(2);
            writer.big(start);
            writer.big(length);
        }
        Some(ContentGeometry::Orbit {
            start,
            length,
            chart_bytes,
            stride,
        }) => {
            writer.byte(3);
            writer.big(start);
            writer.big(length);
            writer.var(*chart_bytes);
            writer.big(stride);
        }
        Some(ContentGeometry::GeneratedBmp { .. } | ContentGeometry::ExactFile { .. }) => {
            return Err(FelixError::Invalid(
                "generated image volumes must remain in their source form".into(),
            ));
        }
    }
    writer.var(branch.children.len() as u64);
    for child in &branch.children {
        put_branch(writer, child)?;
    }
    Ok(())
}

fn get_branch(reader: &mut Reader<'_>) -> Result<Branch> {
    let rotation_state = reader.u32()?;
    let rotation_radix = reader.u32()?;
    let name = reader.word()?;
    let content = match reader.byte()? {
        0 => None,
        1 => Some(ContentGeometry::Angular {
            bytes: reader.word()?,
        }),
        2 => Some(ContentGeometry::Lattice {
            start: reader.big()?,
            length: reader.big()?,
        }),
        3 => Some(ContentGeometry::Orbit {
            start: reader.big()?,
            length: reader.big()?,
            chart_bytes: reader.var()?,
            stride: reader.big()?,
        }),
        tag => {
            return Err(FelixError::Invalid(format!(
                "unknown content geometry {tag}"
            )));
        }
    };
    let count = reader.usize()?;
    let mut children = Vec::with_capacity(count);
    for _ in 0..count {
        children.push(get_branch(reader)?);
    }
    Ok(Branch {
        rotation_state,
        rotation_radix,
        name,
        content,
        children,
    })
}

const B64: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_";

fn base64url_encode(bytes: &[u8]) -> String {
    let mut out = String::with_capacity((bytes.len() * 4 + 2) / 3);
    for chunk in bytes.chunks(3) {
        let value = (chunk[0] as u32) << 16
            | (chunk.get(1).copied().unwrap_or(0) as u32) << 8
            | chunk.get(2).copied().unwrap_or(0) as u32;
        out.push(B64[((value >> 18) & 63) as usize] as char);
        out.push(B64[((value >> 12) & 63) as usize] as char);
        if chunk.len() > 1 {
            out.push(B64[((value >> 6) & 63) as usize] as char);
        }
        if chunk.len() > 2 {
            out.push(B64[(value & 63) as usize] as char);
        }
    }
    out
}

fn base64url_decode(text: &str) -> Result<Vec<u8>> {
    let mut out = Vec::with_capacity(text.len() * 3 / 4);
    let mut value = 0u32;
    let mut bits = 0u8;
    for byte in text.bytes() {
        let digit = B64
            .iter()
            .position(|&candidate| candidate == byte)
            .ok_or_else(|| FelixError::Invalid("invalid base64url digit".into()))?
            as u32;
        value = (value << 6) | digit;
        bits += 6;
        if bits >= 8 {
            bits -= 8;
            out.push((value >> bits) as u8);
            value &= (1u32 << bits).wrapping_sub(1);
        }
    }
    if bits != 0 && value != 0 {
        return Err(FelixError::Invalid("nonzero base64url tail".into()));
    }
    Ok(out)
}

fn crc32(bytes: &[u8]) -> u32 {
    let mut crc = !0u32;
    for &byte in bytes {
        crc ^= byte as u32;
        for _ in 0..8 {
            crc = (crc >> 1) ^ (0xedb8_8320 & (0u32.wrapping_sub(crc & 1)));
        }
    }
    !crc
}
