use std::{fs, path::Path};

use crate::error::{FelixError, Result};

pub const ROTATIONS: u8 = 16;
pub const CELL: usize = 32;
pub const COLUMNS: usize = 32;
pub const MARGIN: usize = 16;

#[derive(Clone, Debug)]
pub struct GrayImage {
    pub width: usize,
    pub height: usize,
    pub pixels: Vec<u8>,
}

impl GrayImage {
    pub fn new(width: usize, height: usize, value: u8) -> Self {
        Self {
            width,
            height,
            pixels: vec![value; width * height],
        }
    }

    pub fn get(&self, x: usize, y: usize) -> u8 {
        self.pixels[y * self.width + x]
    }

    fn set_min(&mut self, x: i32, y: i32, value: u8) {
        if x >= 0 && y >= 0 && (x as usize) < self.width && (y as usize) < self.height {
            let at = y as usize * self.width + x as usize;
            self.pixels[at] = self.pixels[at].min(value);
        }
    }

    pub fn save_bmp(&self, path: impl AsRef<Path>) -> Result<()> {
        let row_bytes = (self.width * 3 + 3) & !3;
        let image_bytes = row_bytes * self.height;
        let file_bytes = 54 + image_bytes;
        let mut out = Vec::with_capacity(file_bytes);
        out.extend_from_slice(b"BM");
        out.extend_from_slice(&(file_bytes as u32).to_le_bytes());
        out.extend_from_slice(&[0; 4]);
        out.extend_from_slice(&54u32.to_le_bytes());
        out.extend_from_slice(&40u32.to_le_bytes());
        out.extend_from_slice(&(self.width as i32).to_le_bytes());
        out.extend_from_slice(&(self.height as i32).to_le_bytes());
        out.extend_from_slice(&1u16.to_le_bytes());
        out.extend_from_slice(&24u16.to_le_bytes());
        out.extend_from_slice(&0u32.to_le_bytes());
        out.extend_from_slice(&(image_bytes as u32).to_le_bytes());
        out.extend_from_slice(&2835u32.to_le_bytes());
        out.extend_from_slice(&2835u32.to_le_bytes());
        out.extend_from_slice(&[0; 8]);
        for y in (0..self.height).rev() {
            for x in 0..self.width {
                let value = self.get(x, y);
                out.extend_from_slice(&[value, value, value]);
            }
            out.resize(out.len() + row_bytes - self.width * 3, 0);
        }
        fs::write(path, out)?;
        Ok(())
    }

    pub fn load_bmp(path: impl AsRef<Path>) -> Result<Self> {
        let bytes = fs::read(path)?;
        if bytes.get(0..2) != Some(b"BM") || bytes.len() < 54 {
            return Err(FelixError::Invalid("angular scan is not a BMP".into()));
        }
        let read_u32 = |at| u32::from_le_bytes(bytes[at..at + 4].try_into().unwrap());
        let offset = read_u32(10) as usize;
        let width = read_u32(18) as usize;
        let height = read_u32(22) as usize;
        let depth = u16::from_le_bytes(bytes[28..30].try_into().unwrap());
        if depth != 24 || width == 0 || height == 0 {
            return Err(FelixError::Invalid(
                "angular BMP must be nonempty 24-bit RGB".into(),
            ));
        }
        let row_bytes = (width * 3 + 3) & !3;
        if bytes.len() < offset + row_bytes * height {
            return Err(FelixError::Invalid("truncated angular BMP".into()));
        }
        let mut image = Self::new(width, height, 255);
        for y in 0..height {
            let source_y = height - 1 - y;
            for x in 0..width {
                let at = offset + source_y * row_bytes + x * 3;
                image.pixels[y * width + x] =
                    ((bytes[at] as u16 + bytes[at + 1] as u16 + bytes[at + 2] as u16) / 3) as u8;
            }
        }
        Ok(image)
    }
}

pub fn render(payload: &[u8]) -> GrayImage {
    let mut framed = Vec::with_capacity(payload.len() + 12);
    framed.extend_from_slice(b"FXA1");
    framed.extend_from_slice(&(payload.len() as u32).to_le_bytes());
    framed.extend_from_slice(&crc32(payload).to_le_bytes());
    framed.extend_from_slice(payload);
    let states: Vec<u8> = framed
        .iter()
        .flat_map(|byte| [byte >> 4, byte & 15])
        .collect();
    let rows = states.len().div_ceil(COLUMNS);
    let mut image = GrayImage::new(MARGIN * 2 + COLUMNS * CELL, MARGIN * 2 + rows * CELL, 255);
    draw_finders(&mut image, rows);
    for (index, &state) in states.iter().enumerate() {
        let column = index % COLUMNS;
        let row = index / COLUMNS;
        let template = mark_template(state);
        let x0 = MARGIN + column * CELL;
        let y0 = MARGIN + row * CELL;
        for y in 0..CELL {
            for x in 0..CELL {
                image.set_min((x0 + x) as i32, (y0 + y) as i32, template[y * CELL + x]);
            }
        }
    }
    image
}

pub fn scan(image: &GrayImage) -> Result<Vec<u8>> {
    if image.width < MARGIN * 2 + COLUMNS * CELL || image.height < MARGIN * 2 + CELL {
        return Err(FelixError::Invalid("angular image is too small".into()));
    }
    let rows = (image.height - MARGIN * 2) / CELL;
    let templates: Vec<Vec<u8>> = (0..ROTATIONS).map(mark_template).collect();
    let mut states = Vec::with_capacity(rows * COLUMNS);
    for row in 0..rows {
        for column in 0..COLUMNS {
            let mut best = (u64::MAX, 0u8);
            for state in 0..ROTATIONS {
                let score = template_distance(image, column, row, &templates[state as usize]);
                if score < best.0 {
                    best = (score, state);
                }
            }
            states.push(best.1);
        }
    }
    let bytes: Vec<u8> = states
        .chunks_exact(2)
        .map(|pair| pair[0] << 4 | pair[1])
        .collect();
    if bytes.get(0..4) != Some(b"FXA1") || bytes.len() < 12 {
        return Err(FelixError::Invalid(
            "angular geometry header was not recovered".into(),
        ));
    }
    let length = u32::from_le_bytes(bytes[4..8].try_into().unwrap()) as usize;
    let expected_crc = u32::from_le_bytes(bytes[8..12].try_into().unwrap());
    let payload = bytes
        .get(12..12 + length)
        .ok_or_else(|| FelixError::Invalid("angular geometry payload is truncated".into()))?;
    if crc32(payload) != expected_crc {
        return Err(FelixError::Invalid(
            "angular geometry checksum mismatch".into(),
        ));
    }
    Ok(payload.to_vec())
}

fn draw_finders(image: &mut GrayImage, rows: usize) {
    for &(x, y) in &[
        (4, 4),
        (image.width as i32 - 5, 4),
        (4, image.height as i32 - 5),
    ] {
        for dy in -3i32..=3 {
            for dx in -3i32..=3 {
                let border = dx.abs() == 3 || dy.abs() == 3;
                image.set_min(x + dx, y + dy, if border { 0 } else { 255 });
            }
        }
    }
    let _ = rows;
}

fn mark_template(state: u8) -> Vec<u8> {
    let mut image = GrayImage::new(CELL, CELL, 255);
    let cx = (CELL / 2) as f64;
    let cy = (CELL / 2) as f64;
    let theta = std::f64::consts::TAU * state as f64 / ROTATIONS as f64;
    for step in 0..=12 {
        let radius = 2.0 + step as f64;
        let x = (cx + theta.cos() * radius).round() as i32;
        let y = (cy + theta.sin() * radius).round() as i32;
        for dy in -1..=1 {
            for dx in -1..=1 {
                image.set_min(x + dx, y + dy, 0);
            }
        }
    }
    let tip_x = (cx + theta.cos() * 13.0).round() as i32;
    let tip_y = (cy + theta.sin() * 13.0).round() as i32;
    for dy in -2..=2 {
        for dx in -2..=2 {
            if dx * dx + dy * dy <= 4 {
                image.set_min(tip_x + dx, tip_y + dy, 0);
            }
        }
    }
    for dy in -1..=1 {
        for dx in -1..=1 {
            image.set_min(cx as i32 + dx, cy as i32 + dy, 64);
        }
    }
    image.pixels
}

fn template_distance(image: &GrayImage, column: usize, row: usize, template: &[u8]) -> u64 {
    let x0 = MARGIN + column * CELL;
    let y0 = MARGIN + row * CELL;
    let mut distance = 0u64;
    for y in y0..y0 + CELL {
        for x in x0..x0 + CELL {
            distance += image.get(x, y).abs_diff(template[(y - y0) * CELL + x - x0]) as u64;
        }
    }
    distance
}

fn crc32(bytes: &[u8]) -> u32 {
    let mut crc = !0u32;
    for &byte in bytes {
        crc ^= byte as u32;
        for _ in 0..8 {
            crc = (crc >> 1) ^ (0xedb8_8320 & (0u32.wrapping_sub(crc & 1)));
        }
    }
    !crc
}
