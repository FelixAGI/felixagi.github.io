#include <jni.h>
#include <stdint.h>
#include <stdlib.h>

typedef struct FelixHandle FelixHandle;
FelixHandle *felix_open(const uint8_t *, size_t);
void felix_close(FelixHandle *);
int32_t felix_kind(const FelixHandle *, const char *, size_t);
uint64_t felix_size(const FelixHandle *, const char *, size_t);
ptrdiff_t felix_list(const FelixHandle *, const char *, size_t, uint8_t *, size_t);
ptrdiff_t felix_read(const FelixHandle *, const char *, size_t, uint64_t, uint8_t *, size_t);

JNIEXPORT jlong JNICALL Java_org_felixqr_felixfs_FelixNative_open(JNIEnv *env, jclass cls, jbyteArray payload) {
    (void)cls;
    jsize length = (*env)->GetArrayLength(env, payload);
    jbyte *bytes = (*env)->GetByteArrayElements(env, payload, NULL);
    FelixHandle *handle = felix_open((const uint8_t *)bytes, (size_t)length);
    (*env)->ReleaseByteArrayElements(env, payload, bytes, JNI_ABORT);
    return (jlong)(intptr_t)handle;
}

JNIEXPORT void JNICALL Java_org_felixqr_felixfs_FelixNative_close(JNIEnv *env, jclass cls, jlong value) {
    (void)env; (void)cls; felix_close((FelixHandle *)(intptr_t)value);
}

static const char *path_chars(JNIEnv *env, jstring path, jsize *length) {
    *length = (*env)->GetStringUTFLength(env, path);
    return (*env)->GetStringUTFChars(env, path, NULL);
}

JNIEXPORT jint JNICALL Java_org_felixqr_felixfs_FelixNative_kind(JNIEnv *env, jclass cls, jlong value, jstring path) {
    (void)cls; jsize length; const char *text = path_chars(env, path, &length);
    int32_t result = felix_kind((FelixHandle *)(intptr_t)value, text, (size_t)length);
    (*env)->ReleaseStringUTFChars(env, path, text); return result;
}

JNIEXPORT jlong JNICALL Java_org_felixqr_felixfs_FelixNative_size(JNIEnv *env, jclass cls, jlong value, jstring path) {
    (void)cls; jsize length; const char *text = path_chars(env, path, &length);
    uint64_t result = felix_size((FelixHandle *)(intptr_t)value, text, (size_t)length);
    (*env)->ReleaseStringUTFChars(env, path, text); return result > INT64_MAX ? INT64_MAX : (jlong)result;
}

JNIEXPORT jstring JNICALL Java_org_felixqr_felixfs_FelixNative_list(JNIEnv *env, jclass cls, jlong value, jstring path) {
    (void)cls; jsize length; const char *text = path_chars(env, path, &length);
    ptrdiff_t needed = felix_list((FelixHandle *)(intptr_t)value, text, (size_t)length, NULL, 0);
    if (needed < 0) { (*env)->ReleaseStringUTFChars(env, path, text); return NULL; }
    uint8_t *buffer = (uint8_t *)malloc((size_t)needed + 1);
    felix_list((FelixHandle *)(intptr_t)value, text, (size_t)length, buffer, (size_t)needed);
    buffer[needed] = 0;
    jstring result = (*env)->NewStringUTF(env, (const char *)buffer);
    free(buffer); (*env)->ReleaseStringUTFChars(env, path, text); return result;
}

JNIEXPORT jint JNICALL Java_org_felixqr_felixfs_FelixNative_read(JNIEnv *env, jclass cls, jlong value, jstring path, jlong offset, jbyteArray output, jint requested) {
    (void)cls; jsize path_length; const char *text = path_chars(env, path, &path_length);
    jbyte *bytes = (*env)->GetByteArrayElements(env, output, NULL);
    ptrdiff_t count = felix_read((FelixHandle *)(intptr_t)value, text, (size_t)path_length,
        (uint64_t)offset, (uint8_t *)bytes, (size_t)requested);
    (*env)->ReleaseByteArrayElements(env, output, bytes, 0);
    (*env)->ReleaseStringUTFChars(env, path, text); return (jint)count;
}
