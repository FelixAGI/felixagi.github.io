package org.felixqr.felixfs;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public final class FelixImportActivity extends Activity {
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(content());
        handle(getIntent());
    }

    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handle(intent);
    }

    private LinearLayout content() {
        int padding = Math.round(24 * getResources().getDisplayMetrics().density);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(padding, padding, padding, padding);

        status = new TextView(this);
        status.setText("FelixFS is ready.");
        status.setGravity(Gravity.CENTER);
        status.setTextSize(18);
        layout.addView(status, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button files = new Button(this);
        files.setText("Open Files");
        files.setOnClickListener(view -> openFiles());
        LinearLayout.LayoutParams button = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        button.topMargin = padding;
        layout.addView(files, button);
        return layout;
    }

    private void handle(Intent intent) {
        String payload = payloadFrom(intent);
        if (payload != null) {
            install(payload);
            return;
        }
        URL locator = locatorFrom(intent);
        if (locator == null) return;
        status.setText("Opening this FelixQR...");
        new Thread(() -> download(locator), "felix-import").start();
    }

    private void install(String payload) {
        try {
            FelixStore.install(getApplicationContext(), payload);
            status.setText("FelixQR mounted.");
            openFiles();
        } catch (IOException error) {
            status.setText("Could not mount this FelixQR: " + error.getMessage());
        }
    }

    private void download(URL locator) {
        try {
            HttpURLConnection connection = (HttpURLConnection) locator.openConnection();
            connection.setConnectTimeout(15_000);
            connection.setReadTimeout(30_000);
            connection.setInstanceFollowRedirects(true);
            try (InputStream input = connection.getInputStream()) {
                byte[] bytes = readPayload(input);
                if (bytes.length > FelixStore.MAX_PAYLOAD_BYTES) {
                    throw new IOException("Felix file exceeds 16 MiB");
                }
                String payload = new String(bytes, StandardCharsets.UTF_8);
                runOnUiThread(() -> install(payload));
            } finally {
                connection.disconnect();
            }
        } catch (IOException error) {
            runOnUiThread(() -> status.setText("Could not open this FelixQR: " + error.getMessage()));
        }
    }

    private static byte[] readPayload(InputStream input) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int remaining = FelixStore.MAX_PAYLOAD_BYTES + 1;
        while (remaining > 0) {
            int count = input.read(buffer, 0, Math.min(buffer.length, remaining));
            if (count < 0) break;
            output.write(buffer, 0, count);
            remaining -= count;
        }
        return output.toByteArray();
    }

    private static String payloadFrom(Intent intent) {
        if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            return payloadFromText(intent.getData().toString());
        }
        if (Intent.ACTION_SEND.equals(intent.getAction()) && "text/plain".equals(intent.getType())) {
            return payloadFromText(intent.getStringExtra(Intent.EXTRA_TEXT));
        }
        return null;
    }

    private static String payloadFromText(String text) {
        if (text == null) return null;
        String value = text.trim();
        if (isPayload(value)) return value;
        Uri uri = Uri.parse(value);
        String fragment = uri.getFragment();
        return fragment != null && isPayload(fragment) ? fragment : null;
    }

    private static boolean isPayload(String value) {
        return value.startsWith("FX1|") || value.startsWith("FQI1|") || value.startsWith("FQX1|");
    }

    private static URL locatorFrom(Intent intent) {
        if (!Intent.ACTION_VIEW.equals(intent.getAction()) || intent.getData() == null) return null;
        try {
            Uri uri = intent.getData();
            String source = "felixfs".equals(uri.getScheme()) ? uri.getQueryParameter("url") : uri.toString();
            if (source == null) return null;
            URL page = new URL(source);
            String set = Uri.parse(source).getQueryParameter("set");
            URL locator = set == null ? page : new URL(page, set);
            String scheme = locator.getProtocol();
            String host = locator.getHost();
            if ("https".equals(scheme) || ("http".equals(scheme) && isPrivateHost(host))) return locator;
        } catch (Exception ignored) {
        }
        return null;
    }

    private static boolean isPrivateHost(String host) {
        return "localhost".equals(host)
            || "127.0.0.1".equals(host)
            || host.startsWith("10.")
            || host.startsWith("192.168.")
            || host.matches("172\\.(1[6-9]|2[0-9]|3[01])\\..*");
    }

    private void openFiles() {
        Uri root = DocumentsContract.buildRootUri(FelixStore.AUTHORITY, FelixStore.ROOT);
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, root));
        } catch (ActivityNotFoundException unavailable) {
            Intent picker = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            picker.addCategory(Intent.CATEGORY_OPENABLE);
            picker.setType("*/*");
            startActivity(picker);
        }
    }
}
