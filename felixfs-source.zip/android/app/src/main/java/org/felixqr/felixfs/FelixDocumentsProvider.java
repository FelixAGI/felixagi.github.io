package org.felixqr.felixfs;

import android.database.Cursor;
import android.database.MatrixCursor;
import android.os.CancellationSignal;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.ParcelFileDescriptor;
import android.os.ProxyFileDescriptorCallback;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;
import android.provider.DocumentsContract.Root;
import android.provider.DocumentsProvider;
import android.system.ErrnoException;
import android.system.OsConstants;
import android.webkit.MimeTypeMap;
import android.os.storage.StorageManager;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Locale;

public final class FelixDocumentsProvider extends DocumentsProvider {
    private HandlerThread ioThread;

    @Override public boolean onCreate() {
        try {
            FelixStore.initialize(getContext());
            ioThread = new HandlerThread("FelixFS geometry");
            ioThread.start();
            return true;
        } catch (IOException error) {
            return false;
        }
    }

    @Override public Cursor queryRoots(String[] projection) {
        MatrixCursor cursor = new MatrixCursor(projection != null ? projection : new String[] {
            Root.COLUMN_ROOT_ID, Root.COLUMN_DOCUMENT_ID, Root.COLUMN_TITLE,
            Root.COLUMN_FLAGS, Root.COLUMN_MIME_TYPES, Root.COLUMN_AVAILABLE_BYTES
        });
        MatrixCursor.RowBuilder row = cursor.newRow();
        row.add(Root.COLUMN_ROOT_ID, FelixStore.ROOT);
        row.add(Root.COLUMN_DOCUMENT_ID, "/");
        row.add(Root.COLUMN_TITLE, "FelixFS");
        row.add(Root.COLUMN_FLAGS, Root.FLAG_SUPPORTS_IS_CHILD);
        row.add(Root.COLUMN_MIME_TYPES, "*/*");
        row.add(Root.COLUMN_AVAILABLE_BYTES, Long.MAX_VALUE);
        cursor.setNotificationUri(getContext().getContentResolver(),
            DocumentsContract.buildRootsUri(FelixStore.AUTHORITY));
        return cursor;
    }

    @Override public Cursor queryDocument(String documentId, String[] projection) {
        MatrixCursor cursor = documentCursor(projection);
        include(cursor, documentId, nameOf(documentId), FelixStore.kind(getContext(), documentId), FelixStore.size(getContext(), documentId));
        cursor.setNotificationUri(getContext().getContentResolver(),
            DocumentsContract.buildDocumentUri(FelixStore.AUTHORITY, documentId));
        return cursor;
    }

    @Override public Cursor queryChildDocuments(String parentDocumentId, String[] projection, String sortOrder) {
        MatrixCursor cursor = documentCursor(projection);
        String listing = FelixStore.list(getContext(), parentDocumentId);
        if (listing == null) return cursor;
        for (String line : listing.split("\n")) {
            if (line.isEmpty()) continue;
            String[] fields = line.split("\\|", 5);
            int kind = fields[0].equals("D") ? 2 : 1;
            long size;
            try { size = Long.parseLong(fields[3]); } catch (NumberFormatException ignored) { size = Long.MAX_VALUE; }
            String path = parentDocumentId.equals("/") ? "/" + fields[4] : parentDocumentId + "/" + fields[4];
            include(cursor, path, fields[4], kind, size);
        }
        cursor.setNotificationUri(getContext().getContentResolver(),
            DocumentsContract.buildChildDocumentsUri(FelixStore.AUTHORITY, parentDocumentId));
        return cursor;
    }

    @Override public String getDocumentType(String documentId) {
        return mime(documentId, FelixStore.kind(getContext(), documentId));
    }

    @Override public boolean isChildDocument(String parentDocumentId, String documentId) {
        String prefix = parentDocumentId.equals("/") ? "/" : parentDocumentId + "/";
        return documentId.startsWith(prefix) && FelixStore.kind(getContext(), documentId) != 0;
    }

    @Override public ParcelFileDescriptor openDocument(String documentId, String mode, CancellationSignal signal)
            throws FileNotFoundException {
        if (!mode.equals("r") || FelixStore.kind(getContext(), documentId) != 1) throw new FileNotFoundException("FelixFS is read-only");
        long size = FelixStore.size(getContext(), documentId);
        StorageManager manager = getContext().getSystemService(StorageManager.class);
        try {
            return manager.openProxyFileDescriptor(ParcelFileDescriptor.MODE_READ_ONLY,
                new ProxyFileDescriptorCallback() {
                @Override public long onGetSize() { return size; }
                @Override public int onRead(long offset, int requested, byte[] data) throws ErrnoException {
                    int count = FelixStore.read(getContext(), documentId, offset, data, requested);
                    if (count < 0) throw new ErrnoException("Felix geometry read", OsConstants.EIO);
                    return count;
                }
                @Override public void onRelease() {}
                }, new Handler(ioThread.getLooper()));
        } catch (IOException error) {
            FileNotFoundException wrapped = new FileNotFoundException(error.getMessage());
            wrapped.initCause(error);
            throw wrapped;
        }
    }

    private MatrixCursor documentCursor(String[] projection) {
        return new MatrixCursor(projection != null ? projection : new String[] {
            Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE,
            Document.COLUMN_SIZE, Document.COLUMN_FLAGS
        });
    }

    private void include(MatrixCursor cursor, String path, String name, int kind, long size) {
        MatrixCursor.RowBuilder row = cursor.newRow();
        row.add(Document.COLUMN_DOCUMENT_ID, path);
        row.add(Document.COLUMN_DISPLAY_NAME, name);
        row.add(Document.COLUMN_MIME_TYPE, mime(path, kind));
        row.add(Document.COLUMN_SIZE, kind == 1 ? size : null);
        row.add(Document.COLUMN_FLAGS, 0);
    }

    private static String nameOf(String path) {
        if (path.equals("/")) return "FelixFS";
        return path.substring(path.lastIndexOf('/') + 1);
    }

    private static String mime(String path, int kind) {
        if (kind == 2) return Document.MIME_TYPE_DIR;
        String extension = MimeTypeMap.getFileExtensionFromUrl(path.toLowerCase(Locale.ROOT));
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        return mime != null ? mime : "application/octet-stream";
    }
}
