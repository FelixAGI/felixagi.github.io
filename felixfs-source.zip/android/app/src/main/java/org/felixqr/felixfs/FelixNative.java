package org.felixqr.felixfs;

final class FelixNative {
    static { System.loadLibrary("felixfs_jni"); }
    static native long open(byte[] payload);
    static native void close(long handle);
    static native int kind(long handle, String path);
    static native long size(long handle, String path);
    static native String list(long handle, String path);
    static native int read(long handle, String path, long offset, byte[] output, int length);
    private FelixNative() {}
}
