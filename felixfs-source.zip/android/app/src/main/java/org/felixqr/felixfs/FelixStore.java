package org.felixqr.felixfs;

import android.content.Context;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.util.AtomicFile;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

final class FelixStore {
    static final String AUTHORITY = "org.felixqr.felixfs.documents";
    static final String ROOT = "felix";
    static final int MAX_PAYLOAD_BYTES = 16 * 1024 * 1024;
    private static long volume;

    static synchronized void initialize(Context context) throws IOException {
        if (volume != 0) return;
        byte[] payload;
        try {
            payload = currentFile(context).readFully();
        } catch (FileNotFoundException missing) {
            try (InputStream input = context.getAssets().open("sample.fx1")) {
                payload = readAll(input);
            }
        }
        volume = open(payload);
    }

    static synchronized void install(Context context, String text) throws IOException {
        byte[] payload = text.trim().getBytes(StandardCharsets.UTF_8);
        long replacement = open(payload);
        AtomicFile file = currentFile(context);
        FileOutputStream output = null;
        try {
            output = file.startWrite();
            output.write(payload);
            file.finishWrite(output);
        } catch (IOException error) {
            if (output != null) file.failWrite(output);
            FelixNative.close(replacement);
            throw error;
        }
        long previous = volume;
        volume = replacement;
        if (previous != 0) FelixNative.close(previous);
        notifyChanged(context);
    }

    static synchronized int kind(Context context, String path) {
        return FelixNative.kind(requireVolume(context), path);
    }

    static synchronized long size(Context context, String path) {
        return FelixNative.size(requireVolume(context), path);
    }

    static synchronized String list(Context context, String path) {
        return FelixNative.list(requireVolume(context), path);
    }

    static synchronized int read(Context context, String path, long offset, byte[] output, int length) {
        return FelixNative.read(requireVolume(context), path, offset, output, length);
    }

    private static long requireVolume(Context context) {
        try {
            initialize(context);
        } catch (IOException error) {
            throw new IllegalStateException("Unable to open FelixFS", error);
        }
        return volume;
    }

    private static long open(byte[] payload) throws IOException {
        if (payload.length == 0 || payload.length > MAX_PAYLOAD_BYTES) {
            throw new IOException("Felix payload must be between 1 byte and 16 MiB");
        }
        long handle = FelixNative.open(payload);
        if (handle == 0) throw new IOException("Invalid Felix payload");
        return handle;
    }

    private static AtomicFile currentFile(Context context) {
        return new AtomicFile(new File(context.getFilesDir(), "current.felix"));
    }

    private static byte[] readAll(InputStream input) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096];
        for (int count; (count = input.read(buffer)) >= 0;) output.write(buffer, 0, count);
        return output.toByteArray();
    }

    private static void notifyChanged(Context context) {
        Uri roots = DocumentsContract.buildRootsUri(AUTHORITY);
        Uri root = DocumentsContract.buildDocumentUri(AUTHORITY, "/");
        Uri children = DocumentsContract.buildChildDocumentsUri(AUTHORITY, "/");
        context.getContentResolver().notifyChange(roots, null);
        context.getContentResolver().notifyChange(root, null);
        context.getContentResolver().notifyChange(children, null);
    }

    private FelixStore() {}
}
