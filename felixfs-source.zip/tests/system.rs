use felixfs::{
    FelixVolume,
    bignat::BigNat,
    sample, scanner,
    vm::{Instruction, Program},
};
use std::{
    io::{Read, Write},
    net::{TcpListener, TcpStream},
    sync::Arc,
    thread,
};

#[test]
fn recursive_arbitrary_precision_addressing_round_trips() {
    let volume = sample::volume();
    assert_eq!(volume.lattice.levels.len(), 3);
    assert_eq!(volume.lattice.dimensions(), 24);
    assert_eq!(volume.lattice.channels, 4);
    assert_eq!(
        volume.lattice.logical_bytes().to_string(),
        "316912650057057350374175801344"
    );
    assert_eq!(BigNat::from(u64::MAX).to_u64(), Some(u64::MAX));
    assert_eq!(volume.lattice.logical_bytes().to_u64(), None);
    let mut address = BigNat::from(7u8);
    for _ in 0..10_000 {
        address = address.mul_u32(1_664_525).add_u64(1_013_904_223);
        while address >= volume.lattice.logical_bytes() {
            let (next, _) = address.div_rem_u32(17);
            address = next;
        }
        let coordinate = volume.lattice.address_to_coordinate(&address).unwrap();
        assert_eq!(
            volume.lattice.coordinate_to_address(&coordinate).unwrap(),
            address
        );
        assert_eq!(coordinate.levels.len(), 3);
    }
}

#[test]
fn compact_record_and_executable_phi_round_trip() {
    let original = sample::volume();
    let payload = original.encode().unwrap();
    assert!(
        payload.len() <= 2_953,
        "FX1 payload is {} bytes",
        payload.len()
    );
    let decoded = FelixVolume::decode(&payload).unwrap();
    let root = decoded.phi.list("/").unwrap();
    assert_eq!(
        root.iter()
            .map(|item| item.name.as_str())
            .collect::<Vec<_>>(),
        ["README.txt", "lattice.bin", "recursive"]
    );
    assert_eq!(
        decoded
            .phi
            .path_states("/recursive/nested/twenty-four-dimensions.bin")
            .unwrap()
            .len(),
        3
    );
    let text = decoded.read("/README.txt", &BigNat::zero(), 4096).unwrap();
    assert!(
        String::from_utf8(text)
            .unwrap()
            .contains("recursive geometric object")
    );
    let a = decoded
        .read("/lattice.bin", &BigNat::from(1_000_000u32), 4096)
        .unwrap();
    let b = decoded
        .read("/lattice.bin", &BigNat::from(1_000_000u32), 4096)
        .unwrap();
    assert_eq!(a, b);
    assert!(a.windows(2).any(|window| window[0] != window[1]));
}

#[test]
fn physical_angular_pixels_recover_payload() {
    let payload = sample::volume().encode().unwrap();
    let mut image = scanner::render(payload.as_bytes());
    for index in (0..image.pixels.len()).step_by(997) {
        image.pixels[index] = image.pixels[index].saturating_sub(23);
    }
    assert_eq!(scanner::scan(&image).unwrap(), payload.as_bytes());
}

#[test]
fn every_vm_operation_executes() {
    use Instruction::*;
    let volume = sample::volume();
    let instructions = vec![
        Const { value: 9 },
        Const { value: 4 },
        Coord { axis: 0 },
        LevelCoord { level: 1, axis: 0 },
        Channel,
        DimensionCount,
        LevelCount,
        Add { a: 0, b: 1 },
        Sub { a: 0, b: 1 },
        Mul { a: 0, b: 1 },
        Div { a: 0, b: 1 },
        Mod { a: 0, b: 1 },
        Xor { a: 0, b: 1 },
        And { a: 0, b: 1 },
        Or { a: 0, b: 1 },
        Not { a: 0 },
        ShiftLeft { a: 0, b: 1 },
        ShiftRight { a: 0, b: 1 },
        RotateLeft { a: 0, b: 1 },
        RotateRight { a: 0, b: 1 },
        Min { a: 0, b: 1 },
        Max { a: 0, b: 1 },
        Equal { a: 0, b: 1 },
        Less { a: 0, b: 1 },
        Greater { a: 0, b: 1 },
        Select {
            condition: 0,
            yes: 0,
            no: 1,
        },
        ByteSwap { a: 0 },
        PopCount { a: 0 },
        Mix64 { a: 0 },
    ];
    assert_eq!(felixfs::vm::OPCODE_COUNT, 28);
    let program = Program {
        instructions,
        outputs: vec![28],
    };
    program.validate(&volume.lattice).unwrap();
    let coordinate = volume
        .lattice
        .address_to_coordinate(&BigNat::zero())
        .unwrap();
    let _ = program.evaluate(&volume.lattice, &coordinate).unwrap();
}

fn dav_request(request: &str) -> Vec<u8> {
    let listener = TcpListener::bind("127.0.0.1:0").unwrap();
    let address = listener.local_addr().unwrap();
    let volume = Arc::new(sample::volume());
    let server = thread::spawn(move || felixfs::webdav::serve_one(listener, volume).unwrap());
    let mut stream = TcpStream::connect(address).unwrap();
    stream.write_all(request.as_bytes()).unwrap();
    stream.shutdown(std::net::Shutdown::Write).unwrap();
    let mut response = Vec::new();
    stream.read_to_end(&mut response).unwrap();
    server.join().unwrap();
    response
}

#[test]
fn desktop_webdav_adapter_lists_and_random_reads() {
    let listing = dav_request("PROPFIND / HTTP/1.1\r\nHost: localhost\r\nDepth: 1\r\n\r\n");
    let listing = String::from_utf8(listing).unwrap();
    assert!(listing.starts_with("HTTP/1.1 207 Multi-Status"));
    assert!(listing.contains("lattice.bin"));
    assert!(listing.contains("recursive"));

    let response =
        dav_request("GET /lattice.bin HTTP/1.1\r\nHost: localhost\r\nRange: bytes=100-131\r\n\r\n");
    let split = response
        .windows(4)
        .position(|window| window == b"\r\n\r\n")
        .unwrap()
        + 4;
    assert!(
        std::str::from_utf8(&response[..split])
            .unwrap()
            .starts_with("HTTP/1.1 206 Partial Content")
    );
    assert_eq!(
        &response[split..],
        sample::volume()
            .read("/lattice.bin", &BigNat::from(100u32), 32)
            .unwrap()
    );
}

#[test]
fn native_adapter_abi_exposes_the_same_phi_tree() {
    let payload = sample::volume().encode().unwrap();
    let path = b"/recursive";
    let file = b"/lattice.bin";
    unsafe {
        let handle = felixfs::ffi::felix_open(payload.as_ptr(), payload.len());
        assert!(!handle.is_null());
        assert_eq!(
            felixfs::ffi::felix_kind(handle, path.as_ptr().cast(), path.len()),
            2
        );
        assert_eq!(
            felixfs::ffi::felix_size(handle, file.as_ptr().cast(), file.len()),
            1u64 << 40
        );
        let needed = felixfs::ffi::felix_list(
            handle,
            path.as_ptr().cast(),
            path.len(),
            std::ptr::null_mut(),
            0,
        );
        assert!(needed > 0);
        let mut listing = vec![0u8; needed as usize];
        assert_eq!(
            felixfs::ffi::felix_list(
                handle,
                path.as_ptr().cast(),
                path.len(),
                listing.as_mut_ptr(),
                listing.len()
            ),
            needed
        );
        assert!(std::str::from_utf8(&listing).unwrap().contains("nested"));
        let mut bytes = [0u8; 32];
        assert_eq!(
            felixfs::ffi::felix_read(
                handle,
                file.as_ptr().cast(),
                file.len(),
                4096,
                bytes.as_mut_ptr(),
                bytes.len()
            ),
            32
        );
        assert_eq!(
            bytes.as_slice(),
            sample::volume()
                .read("/lattice.bin", &BigNat::from(4096u32), 32)
                .unwrap()
        );
        felixfs::ffi::felix_close(handle);
    }
}

#[test]
fn documented_fx1_closed_form_matches_the_vm() {
    let volume = sample::volume();
    let mut address = 7u64;
    for _ in 0..10_000 {
        address = address
            .wrapping_mul(6_364_136_223_846_793_005)
            .wrapping_add(1_442_695_040_888_963_407);
        let coordinate = volume
            .lattice
            .address_to_coordinate(&BigNat::from(address))
            .unwrap();
        let mut hash = 0x9e37_79b9_7f4a_7c15u64;
        for (axis, value) in volume.lattice.flatten(&coordinate).enumerate() {
            let coefficient = 0x1000_0000_01b3u64.wrapping_add(axis as u64 * 0x9e37);
            hash = felixfs::vm::mix64(hash ^ coefficient.wrapping_mul(value as u64));
        }
        let channel = coordinate.channel;
        let expected = felixfs::vm::mix64(hash ^ felixfs::vm::mix64(channel as u64))
            .rotate_right(channel * 8) as u8;
        assert_eq!(
            volume.read_geometry(&BigNat::from(address)).unwrap(),
            expected
        );
    }
}

#[test]
fn fqx1_preserves_the_original_file_byte_for_byte() {
    let payload = include_str!("../demo/goat-1000.fqx");
    let volume = FelixVolume::decode(payload).unwrap();
    let files = volume.phi.list("/files").unwrap();
    assert_eq!(files.len(), 1000);
    assert_eq!(files.first().unwrap().name, "goat-0001.png");
    assert_eq!(files.last().unwrap().name, "goat-1000.png");
    assert_eq!(files[0].length.to_u64(), Some(2_281_094));

    let first = volume
        .read("/files/goat-0001.png", &BigNat::zero(), 2_281_094)
        .unwrap();
    let last = volume
        .read("/files/goat-1000.png", &BigNat::zero(), 2_281_094)
        .unwrap();
    assert_eq!(first, last);
    assert_eq!(first.len(), 2_281_094);
    assert_eq!(&first[..8], b"\x89PNG\r\n\x1a\n");
}

#[test]
fn native_abi_reads_the_exact_fqx1_file_set() {
    let payload = include_str!("../demo/goat-1000.fqx");
    let first = b"/files/goat-0001.png";
    let last = b"/files/goat-1000.png";
    unsafe {
        let handle = felixfs::ffi::felix_open(payload.as_ptr(), payload.len());
        assert!(!handle.is_null());
        assert_eq!(
            felixfs::ffi::felix_size(handle, first.as_ptr().cast(), first.len()),
            2_281_094
        );
        let mut a = [0u8; 64];
        let mut b = [0u8; 64];
        assert_eq!(
            felixfs::ffi::felix_read(
                handle,
                first.as_ptr().cast(),
                first.len(),
                1_000_000,
                a.as_mut_ptr(),
                a.len()
            ),
            64
        );
        assert_eq!(
            felixfs::ffi::felix_read(
                handle,
                last.as_ptr().cast(),
                last.len(),
                1_000_000,
                b.as_mut_ptr(),
                b.len()
            ),
            64
        );
        assert_eq!(a, b);
        felixfs::ffi::felix_close(handle);
    }
}
