#!/bin/sh
set -eu
payload=${1:?usage: mount.sh PAYLOAD MOUNTPOINT [PORT]}
mountpoint=${2:?usage: mount.sh PAYLOAD MOUNTPOINT [PORT]}
port=${3:-49152}
felix=${FELIX:-felix}
mkdir -p "$mountpoint"
"$felix" serve "$payload" "127.0.0.1:$port" &
server=$!
trap 'umount "$mountpoint" 2>/dev/null || true; kill "$server" 2>/dev/null || true' EXIT INT TERM
mount_webdav -S -v FelixFS "http://127.0.0.1:$port/" "$mountpoint"
echo "FelixFS mounted read-only at $mountpoint"
wait "$server"
