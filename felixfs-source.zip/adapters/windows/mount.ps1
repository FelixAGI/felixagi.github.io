param(
    [Parameter(Mandatory=$true)][string]$Payload,
    [string]$Drive = "X:",
    [string]$Root = (Join-Path $env:LOCALAPPDATA "FelixFS\mount"),
    [string]$Felix = "felix.exe"
)

$ErrorActionPreference = "Stop"
New-Item -ItemType Directory -Force -Path $Root | Out-Null
try {
    & $Felix mount-windows $Payload $Root $Drive
} finally {
    & subst.exe $Drive /D 2>$null
    & $Felix unmount-windows $Root $Drive 2>$null
}
