param(
    [string]$Drive = "X:",
    [string]$Root = (Join-Path $env:LOCALAPPDATA "FelixFS\mount"),
    [string]$Felix = "felix.exe"
)
& $Felix unmount-windows $Root $Drive
